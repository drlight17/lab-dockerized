<?php
/** Boldon James Classifier Management schema extension for Active Directory */

class boldon_james_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		$this->attribute_schema = array(
			array("name"=>"bjClearanceConfigClearanceXML",			"data_type"=>"text_area"),
			array("name"=>"bjClearanceConfigOverride",			"data_type"=>"yes_no"),
			array("name"=>"bjClearanceConfigProvisioningDelayTimer",	"data_type"=>"text"),
			array("name"=>"bjClearanceConfigProvisioningPollingInterval",	"data_type"=>"text"),
			array("name"=>"bjClearanceConfigProvisioningUsePollingTimeout",	"data_type"=>"yes_no"),
			array("name"=>"bjClearanceConfigSchemaVersion",			"data_type"=>"text"),
			array("name"=>"bjClearanceConfigSmtpDomain",			"data_type"=>"text"),
			array("name"=>"bjClearanceConfigTemplatePriority",		"data_type"=>"text"),
			array("name"=>"bjClearanceConfigTemplateSearchBase",		"data_type"=>"dn"),
			array("name"=>"bjClearanceConfigTemplateSearchDepth",		"data_type"=>"text"),
			array("name"=>"bjClearanceConfigTemplateSearchFilter",		"data_type"=>"text"),
			array("name"=>"bjClearanceConfigTemplateSearchFilterType",	"data_type"=>"text"),
			array("name"=>"bjClearanceConfigTemplateVersion",		"data_type"=>"text"),
			array("name"=>"bjCM-DataContent",				"data_type"=>"text_area"),
			array("name"=>"bjLabelPolicyEncoderTemplatesXML",		"data_type"=>"text_area"),
			array("name"=>"bjLabelPolicyLabelConfigXML",			"data_type"=>"text_area"),
			array("name"=>"bjLabelPolicyLabelObjectsXML",			"data_type"=>"text"),
			array("name"=>"bjLabelPolicyLabelPolicyMapXML",			"data_type"=>"text"),
			array("name"=>"bjLabelPolicyLabelToolBarConfigXML",		"data_type"=>"text"),
			array("name"=>"bjLabelPolicyLabelUIConfigXML",			"data_type"=>"text")
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"bjCM-Container",				"icon"=>"folder.png",		"is_folder"=>true,"parent_class"=>"container"),
			array("name"=>"bjCM-Document",				"icon"=>"document.png",		"is_folder"=>false,"parent_class"=>"document"),

			array("name"=>"bjClearanceConfig",			"icon"=>"generic24.png",	"class_type"=>"type88","is_folder"=>false,"parent_class"=>"container"),
			array("name"=>"bjClearanceConfigProvisioning",		"icon"=>"generic24.png",	"class_type"=>"type88","is_folder"=>false,"parent_class"=>"container"),
			array("name"=>"bjClearanceConfigSmtpDomainObject",	"icon"=>"generic24.png",	"class_type"=>"type88","is_folder"=>false,"parent_class"=>"container"),
			array("name"=>"bjClearanceConfigTemplate",		"icon"=>"generic24.png",	"class_type"=>"type88","is_folder"=>false,"parent_class"=>"container"),
			array("name"=>"bjLabelPolicyObject",			"icon"=>"generic24.png",	"class_type"=>"type88","is_folder"=>false,"parent_class"=>"container")
			);

                $ldap_server->add_display_layout("bjCM-Document",array(
                        array("section_name"=>gettext("Boldon James Document"),
                                "attributes"=>array(
					array("cn",				gettext("Document Name"),	"document.png")
                                        )
                                ),
                        array("section_name"=>gettext("Document Content"),"new_row"=>true,
                                "attributes"=>array(
                                        array("bjCM-DataContent")
                                        )
                                )
                        ));

		parent::__construct($ldap_server);
	}
}
?>
