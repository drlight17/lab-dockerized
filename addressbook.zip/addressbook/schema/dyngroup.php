<?php
/** Dynamic group schema (dyngroup.schema)

    @see https://tools.ietf.org/html/draft-haripriya-dynamicgroup-02
*/

class dyngroup_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"dgAuthz",			"data_type"=>"text_list",	"display_name"=>gettext("Member URL Processing Identity Authorization Rules")),
			array("name"=>"dgIdentity",			"data_type"=>"dn",		"display_name"=>gettext("Member URL Processing Identity")),
			array("name"=>"memberURL",			"data_type"=>"text_list",	"display_name"=>gettext("Member Query URL"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"dgIdentityAux",			"icon"=>"dyngroup.png",		"class_type"=>"auxiliary","display_name"=>gettext("Dynamic Group Processing Identity")),
			array("name"=>"groupOfURLs",			"icon"=>"dyngroup.png",		"is_folder"=>false,"display_name"=>gettext("Dynamic Group"))
			);

		// Display layouts

		$ldap_server->add_display_layout("groupOfURLs",array(
			array("colspan"=>2,"new_row"=>true,
				"attributes"=>array(
					array("cn",				gettext("Group Name"),		"dyngroup.png"),
					array("description",			gettext("Description"),		"description.png"),

					// array("ou",				gettext("Department"),		"org.png"),
					// array("o",				gettext("Organization"),	"company.png"),
					// array("businessCategory",		gettext("Business Category"),	"company.png"),
					// array("owner",			gettext("Owner"),		"alias.png"),
					// array("seeAlso",			gettext("See Also"),		"alias.png"),

					array("memberURL",			gettext("Member Query URL"),	"labeled-uri.png"),
					)
				),
			array("section_name"=>gettext("Group Members"),"new_row"=>true,"width"=>"50%",
				"attributes"=>array(
					array("member","allow_edit"=>false)
					)
				)
			));

		// Auxiliary class display layouts

		$ldap_server->add_display_layout("dgIdentityAux",array(
			array("section_name"=>gettext("Dynamic Group Processing Identity"),"colspan"=>2,"new_row"=>true,
				"attributes"=>array(
					array("dgIdentity",			gettext("Processing Identity"),	"alias.png"),
					array("dgAuthz",			gettext("Authorization Policy"),"generic24.png"),
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
