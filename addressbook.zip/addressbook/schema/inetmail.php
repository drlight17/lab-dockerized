<?php
/** LDAP Schema for Internet Mail

    @see https://tools.ietf.org/html/draft-srivastava-ldap-mail-00

    Attribute rfc822MailMember can be changed to text_list if more than
    one alias or forwarding destination is going to be used.
*/

class inetmail_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"rfc822MailMember",		"data_type"=>"text",		"display_name"=>gettext("Destination Mailbox"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"nisMailAlias",			"icon"=>"generic24.png",		"is_folder"=>false,"display_name"=>gettext("NIS Mail Alias"))
			);

		// Display layouts

		$ldap_server->add_display_layout("nisMailAlias",array(
			array("section_name"=>gettext("NIS Mail Alias"),
				"attributes"=>array(
					array("cn",			gettext("Incoming E-Mail Address"),		"generic24.png"),
					array("rfc822MailMember",	gettext("Destination Mailbox"),			"mailbox-server.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
