<?php
/** Java schema (java.schema)

    This schema allows Java objects to be represented in an LDAP directory. Objects can be stored
    directly (in the javaSerializedData binary attribute) or refered to via a URL (javaCodebase).

    @see https://www.ietf.org/rfc/rfc2713.txt

    @todo Inheritance of required_attribs by auxiliary classes is not implemented yet.
	Strictly, javaClassName should be defined as a required attribute of javaObject, not of its derived classes.

    @todo Inheritance of additional of display layouts from parents of auxiliary classes is not implemented yet.
	This would enable a common display layout to be used for the javaObject attributes.
*/

class java_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"javaClassName",			"data_type"=>"text",		"display_name"=>gettext("Primary Class/Interface Name")),
			array("name"=>"javaClassNames",			"data_type"=>"text_list",	"display_name"=>gettext("Additional Class/Interface Names")),
			array("name"=>"javaCodebase",			"data_type"=>"text_list",	"display_name"=>gettext("Codebase URL")),
			array("name"=>"javaDoc",			"data_type"=>"text_list",	"display_name"=>gettext("Documentation URL")),
			array("name"=>"javaFactory",			"data_type"=>"text",		"display_name"=>gettext("Object Factory Class Name")),
			array("name"=>"javaReferenceAddress",		"data_type"=>"text_list",	"display_name"=>gettext("JNDI Reference Address")),
			array("name"=>"javaSerializedData;binary",	"data_type"=>"download",	"display_name"=>gettext("Serialized Object Data"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"javaContainer",			"icon"=>"java.png",		"is_folder"=>false,"display_name"=>gettext("Java Object")),
			array("name"=>"javaMarshalledObject",		"icon"=>"java.png",		"class_type"=>"auxiliary","display_name"=>gettext("Java Marshalled Object"),"required_attribs"=>"javaClassName","parent_class"=>"javaObject","can_create"=>true),
			array("name"=>"javaNamingReference",		"icon"=>"java.png",		"class_type"=>"auxiliary","display_name"=>gettext("JNDI Naming Reference"),"required_attribs"=>"javaClassName","parent_class"=>"javaObject","can_create"=>true),
			array("name"=>"javaObject",			"icon"=>"generic24.png",	"class_type"=>"abstract"),
			array("name"=>"javaSerializedObject",		"icon"=>"java.png",		"class_type"=>"auxiliary","display_name"=>gettext("Java Serialized Object"),"required_attribs"=>"javaClassName","parent_class"=>"javaObject","can_create"=>true)
			);

		// Display layouts

		$ldap_server->add_display_layout("javaContainer",array(
			array("section_name"=>gettext("Java Object Container"),
				"attributes"=>array(
					array("cn",				gettext("Container Object Name"),	"java.png")
					)
				)
			));

		// Auxiliary class display layouts

		$ldap_server->add_display_layout("javaMarshalledObject,javaSerializedObject",array(
			array("section_name"=>gettext("Object Details"),
				"attributes"=>array(
					array("javaClassName",			gettext("Primary Class Name"),		"object.png"),
					array("javaClassNames",			gettext("Additional Class Names"),	"object.png"),
					array("javaCodebase",			gettext("Codebase URL"),		"labeled-uri.png"),
					array("javaDoc",			gettext("Documentation URL"),		"document.png"),
					array("description",			gettext("Description"),			"description.png")
					)
				),
			array("section_name"=>gettext("Serialized Object Data"),"new_row"=>true,
				"attributes"=>array(
					array("javaSerializedData;binary"),
					)
				)
			));

		$ldap_server->add_display_layout("javaNamingReference",array(
			array("section_name"=>gettext("Object Details"),
				"attributes"=>array(
					array("javaClassName",			gettext("Primary Class Name"),		"object.png"),
					array("javaClassNames",			gettext("Additional Class Names"),	"object.png"),
					array("javaCodebase",			gettext("Codebase URL"),		"labeled-uri.png"),
					array("javaDoc",			gettext("Documentation URL"),		"document.png"),
					array("description",			gettext("Description"),			"description.png")
					)
				),
			array("section_name"=>gettext("JNDI Naming Reference"),"new_row"=>true,
				"attributes"=>array(
					array("javaFactory",			gettext("Factory Class Name"),		"object.png"),
					array("javaReferenceAddress",		gettext("JNDI Address"),		"labeled-uri.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
