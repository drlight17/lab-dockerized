<?php
/** Trac LDAP Plugin Schema (trac.schema)

    Allows Trac user accounts/permissions to be stored in LDAP.

    The tracuser object class uses a number of attributes defined in
    the core LDAP schema (RFC2256).

    @see https://trac-hacks.org/wiki/LdapPlugin
    @see http://www.ietf.org/rfc/rfc2256.txt
*/

class trac_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"tracperm",			"data_type"=>"text_list",	"display_name"=>gettext("Trac Permissions"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"tracuser",			"icon"=>"trac-user.png",	"is_folder"=>false,"rdn_attrib"=>"uid","display_name"=>gettext("Trac User"),"required_attribs"=>"cn,userPassword","can_create"=>true),
			array("name"=>"tracgroup",			"icon"=>"trac.png",		"class_type"=>"auxiliary","display_name"=>gettext("Trac Permissions"),"can_create"=>true)
			);

		// Display layouts

		$ldap_server->add_display_layout("tracuser",array(
			array("section_name"=>gettext("Login Details"),"new_row"=>true,
				"attributes"=>array(
					array("uid",				gettext("User ID"),		"id.png"),
					array("userPassword",			gettext("Password"),		"password.png")
					)
				),
			array("section_name"=>gettext("User Information"),"new_row"=>true,
				"attributes"=>array(
					array("cn",				gettext("User Name"),		"user24.png"),
					array("sn",				gettext("Surname"),		"contact24.png"),
					array("description",			gettext("Description"),		"description.png")
					)
				),
			array("section_name"=>gettext("Trac Permissions"),"new_row"=>true,
				"attributes"=>array(
					array("tracperm")
					)
				)
			));

                $ldap_server->add_display_layout("tracgroup",array(
			array("section_name"=>gettext("Trac Permissions"),
				"attributes"=>array(
					array("tracperm")
					)
				)
			));

                parent::__construct($ldap_server);
        }
}
?>
