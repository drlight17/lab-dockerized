<?php
/** X.509 Privilege Management Infrastructure Schema (pmi.schema)

    @see https://tools.ietf.org/html/draft-ietf-pkix-ldap-schema-02
    @see https://www.itu.int/rec/T-REC-X.509-201610-I/en
*/

class pmi_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"aACertificatee;binary",			"data_type"=>"download",	"display_name"=>gettext("Attribute Authority Certificate")),
			array("name"=>"attributeAuthorityRevocationList;binary","data_type"=>"download",	"display_name"=>gettext("Attribute Authority Revocation List")),
			array("name"=>"attributeCertificateAttribute;binary",	"data_type"=>"download",	"display_name"=>gettext("Attribute Certificate")),
			array("name"=>"attributeCertificateRevocationList;binary","data_type"=>"download",	"display_name"=>gettext("Attribute Certificate Revocation List")),
			array("name"=>"attributeDescriptorCertificate;binary",	"data_type"=>"download",	"display_name"=>gettext("Attribute Descriptor Certificate")),
			array("name"=>"delegationPath;binary",			"data_type"=>"download",	"display_name"=>gettext("Delegation Path")),
			array("name"=>"privPolicy;binary",			"data_type"=>"download",	"display_name"=>gettext("Privilege Policy")),
			array("name"=>"protPrivPolicy;binary",			"data_type"=>"download",	"display_name"=>gettext("Protected Privilege Policy")),
			array("name"=>"role;binary",				"data_type"=>"download",	"display_name"=>gettext("Role")),
			array("name"=>"xmlPrivilegeInfo",			"data_type"=>"text_area",	"display_name"=>gettext("XML Privilege Information")),
			array("name"=>"xmlPrivPolicy",				"data_type"=>"text_area",	"display_name"=>gettext("XML Protected Privilege Policy")),
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"attCertCRLDistributionPt",	"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Attribute Certificate Revocation List Distribution Point")),
			array("name"=>"pmiAA",				"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("PMI Attribute Authority")),
			array("name"=>"pmiDelegationPath",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("PMI Delegation Path")),
			array("name"=>"pmiSOA",				"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("PMI Source of Authority")),
			array("name"=>"pmiUser",			"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Privilege Holder")),
			array("name"=>"privilegePolicy",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Privilege Policy")),
			array("name"=>"protectedPrivilegePolicy",	"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Protected Privilege Policy")),
			);

		parent::__construct($ldap_server);
	}
}
?>
