<?php
/** Novell Domain Name/IP Address Management (DNS, NetWare DHCP) schema

    Novell DHCP Server (for NetWare) was replaced by an LDAP-enabled ISC DHCP Server
    in OpenEnterprise Server (for Linux). The DHCP portion of DNIP is superceded by
    the ISC DHCP schema.

    The DNIP schema was submitted as an IETF Internet Draft (see below) but was
    not carried forward to become an RFC or Standard.

    @see https://tools.ietf.org/html/draft-miller-dhcp-ldap-schema-00
    @see https://tools.ietf.org/html/draft-miller-dns-ldap-schema-00
*/

class novell_dnip_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		$this->attribute_schema = array(
			array("name"=>"dnipAdditionalOptions",		"data_type"=>"text_list",	"display_name"=>gettext("Additional Options")),
			array("name"=>"dnipAddressNumber",		"data_type"=>"text",		"display_name"=>gettext("Address Number")),
			array("name"=>"dnipAliasedObjectName",		"data_type"=>"dn_list",		"display_name"=>gettext("Associated NDS Object")),
			array("name"=>"dnipAllowRecursion",		"data_type"=>"text_list",	"display_name"=>gettext("Allow Recursion")),
			array("name"=>"dnipAlsoNotify",			"data_type"=>"download_list",	"display_name"=>gettext("Also Notify")),
			array("name"=>"dnipAssignmentType",		"data_type"=>"text",		"display_name"=>gettext("Assignment Type")),
			array("name"=>"dnipAuditLevel",			"data_type"=>"text",		"display_name"=>gettext("Audit Level")),
			array("name"=>"dnipAutoHostNameStart",		"data_type"=>"text",		"display_name"=>gettext("Auto Host Name Start")),
			array("name"=>"dnipBlacklistServers",		"data_type"=>"download_list",	"display_name"=>gettext("Blacklisted Servers")),
			array("name"=>"dnipBootParameter",		"data_type"=>"download",	"display_name"=>gettext("Boot Parameter")),
			array("name"=>"dnipCfgPreferences",		"data_type"=>"download_list",	"display_name"=>gettext("Configuration Preferences")),
			array("name"=>"dnipClientIdentifier",		"data_type"=>"download",	"display_name"=>gettext("Client Identifier")),
			array("name"=>"dnipComment",			"data_type"=>"text_area",	"display_name"=>gettext("Comments")),
			array("name"=>"dnipConfigOptions",		"data_type"=>"download",	"display_name"=>gettext("Configuration Options")),
			array("name"=>"dnipDesignatedServer",		"data_type"=>"dn",		"display_name"=>gettext("Designated Server")),
			array("name"=>"dnipDHCPServerReference",	"data_type"=>"dn",		"display_name"=>gettext("DHCP Server Reference")),
			array("name"=>"dnipDHCPServers",		"data_type"=>"dn_list",		"display_name"=>gettext("DHCP Servers")),
			array("name"=>"dnipDHCPServerVersion",		"data_type"=>"text",		"display_name"=>gettext("DHCP Server Version")),
			array("name"=>"dnipDHCPVersion",		"data_type"=>"text",		"display_name"=>gettext("DHCP Version")),
			array("name"=>"dnipDNSDomainName",		"data_type"=>"text",		"display_name"=>gettext("DNS Domain Name")),
			array("name"=>"dnipDNSServerOptions",		"data_type"=>"text",		"display_name"=>gettext("DNS Server Options")),
			array("name"=>"dnipDNSServerReference",		"data_type"=>"dn",		"display_name"=>gettext("DNS Server Reference")),
			array("name"=>"dnipDNSServers",			"data_type"=>"dn_list",		"display_name"=>gettext("DNS Servers")),
			array("name"=>"dnipDNSServerVersion",		"data_type"=>"text",		"display_name"=>gettext("DNS Server Version")),		// TODO: missing data type
			array("name"=>"dnipDNSUpdateOption",		"data_type"=>"text",		"display_name"=>gettext("DNS Update Option")),
			array("name"=>"dnipDNSZones",			"data_type"=>"dn_list",		"display_name"=>gettext("DNS Zone Object Names")),
			array("name"=>"dnipDomainName",			"data_type"=>"text",		"display_name"=>gettext("Domain Name")),
			array("name"=>"dnipEndAddressNumber",		"data_type"=>"text",		"display_name"=>gettext("End Address Number")),
			array("name"=>"dnipExcludedMAC",		"data_type"=>"download_list",	"display_name"=>gettext("Excluded MAC")),
			array("name"=>"dnipFQDomainName",		"data_type"=>"text",		"display_name"=>gettext("FQ Domain Name")),
			array("name"=>"dnipFTAutomatic",		"data_type"=>"yes_no",		"display_name"=>gettext("FT Automatic")),
			array("name"=>"dnipFTSyncDelay",		"data_type"=>"text",		"display_name"=>gettext("FT Sync Delay")),
			array("name"=>"dnipFTUpdateInterval",		"data_type"=>"text",		"display_name"=>gettext("FT Update Interval")),
			array("name"=>"dnipFwdList",			"data_type"=>"download",	"display_name"=>gettext("Forward List")),
			array("name"=>"dnipGroupReference",		"data_type"=>"dn_list",		"display_name"=>gettext("DNS/DHCP Group Object Name")),
			array("name"=>"dnipHostName",			"data_type"=>"text",		"display_name"=>gettext("Host Name")),
			array("name"=>"dnipIncludedMAC",		"data_type"=>"download_list",	"display_name"=>gettext("Included MAC")),
			array("name"=>"dnipIPAssignmentPolicy",		"data_type"=>"text",		"display_name"=>gettext("IP Assignment Policy")),
			array("name"=>"dnipJournalLog",			"data_type"=>"download",	"display_name"=>gettext("Journal Log")),
			array("name"=>"dnipLastUsed",			"data_type"=>"date_time",	"display_name"=>gettext("Last Used")),
			array("name"=>"dnipLeaseExpiration",		"data_type"=>"date_time",	"display_name"=>gettext("Lease Expiration")),
			array("name"=>"dnipLeaseTime",			"data_type"=>"text",		"display_name"=>gettext("Lease Time")),
			array("name"=>"dnipLocatorPtr",			"data_type"=>"dn",		"display_name"=>gettext("DNS/DHCP Locator DN")),
			array("name"=>"dnipMACAddress",			"data_type"=>"download",	"display_name"=>gettext("MAC Address")),
			array("name"=>"dnipMasterServerIPAddr",		"data_type"=>"download",	"display_name"=>gettext("Master Server IP Address")),
			array("name"=>"dnipMaxCacheSize",		"data_type"=>"text",		"display_name"=>gettext("Maximum Cache Size")),
			array("name"=>"dnipMaxRecursionLookups",	"data_type"=>"text",		"display_name"=>gettext("Maximum Recursion Lookups")),
			array("name"=>"dnipMessageID",			"data_type"=>"text",		"display_name"=>gettext("Message ID")),
			array("name"=>"dnipNewAttrib",			"data_type"=>"download",	"display_name"=>gettext("New Attribute")),
			array("name"=>"dnipNoFwdList",			"data_type"=>"text_list",	"display_name"=>gettext("No-Forward List")),
			array("name"=>"dnipObjectReference",		"data_type"=>"dn",		"display_name"=>gettext("Object Reference")),
			array("name"=>"dnipPingEnable",			"data_type"=>"text",		"display_name"=>gettext("Ping Enabled")),
			array("name"=>"dnipPrimaryServerReference",	"data_type"=>"dn",		"display_name"=>gettext("Primary Server")),
			array("name"=>"dnipPublicKey",			"data_type"=>"download",	"display_name"=>gettext("Public Key")),
			array("name"=>"dnipQueryFilter",		"data_type"=>"text_list",	"display_name"=>gettext("Query Filter")),
			array("name"=>"dnipRangeType",			"data_type"=>"text",		"display_name"=>gettext("Range Type")),
			array("name"=>"dnipRR",				"data_type"=>"dnip_rr",		"display_name"=>gettext("DNS Resource Record")),
			array("name"=>"dnipRRCount",			"data_type"=>"text",		"display_name"=>gettext("Resource Record Count")),
			array("name"=>"dnipRRSetOptions",		"data_type"=>"text",		"display_name"=>gettext("Resource Record Set Options")),
			array("name"=>"dnipRRStatus",			"data_type"=>"text",		"display_name"=>gettext("Resource Record Status")),
			array("name"=>"dnipSecondaryServerIPAddress",	"data_type"=>"download",	"display_name"=>gettext("Secondary Server IP Address")),
			array("name"=>"dnipSecondaryServerReference",	"data_type"=>"dn",		"display_name"=>gettext("Secondary Server")),
			array("name"=>"dnipSecondaryZone",		"data_type"=>"yes_no",		"display_name"=>gettext("DNS Secondary Zone")),
			array("name"=>"dnipServerDN",			"data_type"=>"dn",		"display_name"=>gettext("Server DN")),
			array("name"=>"dnipServerDNSNames",		"data_type"=>"text_list",	"display_name"=>gettext("Server DNS Names")),
			array("name"=>"dnipServerIPAddress",		"data_type"=>"download_list",	"display_name"=>gettext("Server IP Address")),
			array("name"=>"dnipSNMPTrapFlag",		"data_type"=>"text",		"display_name"=>gettext("SNMP Trap Flag")),
			array("name"=>"dnipSOAAdminMailbox",		"data_type"=>"text",		"display_name"=>gettext("SOA Admin Mailbox")),
			array("name"=>"dnipSOAExpire",			"data_type"=>"text",		"display_name"=>gettext("SOA Expire")),
			array("name"=>"dnipSOAMinimum",			"data_type"=>"text",		"display_name"=>gettext("SOA Minimum")),
			array("name"=>"dnipSOARefresh",			"data_type"=>"text",		"display_name"=>gettext("SOA Refresh")),
			array("name"=>"dnipSOARetry",			"data_type"=>"text",		"display_name"=>gettext("SOA Retry")),
			array("name"=>"dnipSOASerial",			"data_type"=>"text",		"display_name"=>gettext("SOA Serial")),
			array("name"=>"dnipSOAZoneMaster",		"data_type"=>"text",		"display_name"=>gettext("SOA Zone Master")),
			array("name"=>"dnipStartAddressNumber",		"data_type"=>"text",		"display_name"=>gettext("Start Address Number")),
			array("name"=>"dnipSubnetAddress",		"data_type"=>"text",		"display_name"=>gettext("Subnet Address")),
			array("name"=>"dnipSubnetAddressRangeAttr",	"data_type"=>"dn_list",		"display_name"=>gettext("Subnet Address Range Attribute")),
			array("name"=>"dnipSubnetAttr",			"data_type"=>"dn_list",		"display_name"=>gettext("DHCP Subnet Attribute Object Names")),
			array("name"=>"dnipSubnetMask",			"data_type"=>"text",		"display_name"=>gettext("Subnet Mask")),
			array("name"=>"dnipSubnetPoolList",		"data_type"=>"dn_list",		"display_name"=>gettext("Subnet Pool List")),
			array("name"=>"dnipSubnetPoolReference",	"data_type"=>"dn_list",		"display_name"=>gettext("Subnet Pool Reference")),
			array("name"=>"dnipSubnetType",			"data_type"=>"text",		"display_name"=>gettext("Subnet Type")),
			array("name"=>"dnipUISignature",		"data_type"=>"download_list",	"display_name"=>gettext("UI Signature")),
			array("name"=>"dnipUpdateFilter",		"data_type"=>"text_list",	"display_name"=>gettext("Update Filter")),
			array("name"=>"dnipZoneDomainName",		"data_type"=>"text",		"display_name"=>gettext("Zone Domain Name")),
			array("name"=>"dnipZoneList",			"data_type"=>"dn_list",		"display_name"=>gettext("Zone List")),
			array("name"=>"dnipZoneOptions",		"data_type"=>"text",		"display_name"=>gettext("Zone Options")),
			array("name"=>"dnipZoneOutFilter",		"data_type"=>"text_list",	"display_name"=>gettext("Zone Out Filter")),
			array("name"=>"dnipZoneReference",		"data_type"=>"dn_list",		"display_name"=>gettext("Zone Reference")),
			array("name"=>"dnipZoneServers",		"data_type"=>"dn_list",		"display_name"=>gettext("Zone Servers")),
			array("name"=>"dnipZoneType",			"data_type"=>"text",		"display_name"=>gettext("Zone Type")),
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"dNIPDHCPServer",			"icon"=>"dhcp/dhcp-server.png",			"is_folder"=>false,"display_name"=>gettext("DHCP Server (NetWare)")),
			array("name"=>"dnipDNSDHCPServerVersion",	"icon"=>"generic24.png",			"class_type"=>"auxiliary","display_name"=>gettext("DNS/DHCP Server Versions")),
			array("name"=>"dNIPDNSKey",			"icon"=>"dhcp/dhcp-dns-key.png",		"is_folder"=>false,"display_name"=>gettext("DNIP:DNS Key")),
			array("name"=>"dNIPDNSRRset",			"icon"=>"document-series.png",			"is_folder"=>false,"display_name"=>gettext("DNS RRset")),
			array("name"=>"dNIPDNSServer",			"icon"=>"novell/dns-server.png",		"is_folder"=>false,"display_name"=>gettext("DNS Server")),
			array("name"=>"dNIPDNSZone",			"icon"=>"novell/dnip-dns-zone.png",		"is_folder"=>false,"display_name"=>gettext("DNS Zone")),
			array("name"=>"dNIPIPAddressConfiguration",	"icon"=>"dhcp/dhcp-host.png",			"is_folder"=>false,"display_name"=>gettext("IP Address Configuration")),
			array("name"=>"dNIPLocator",			"icon"=>"dhcp/dhcp-locator.png",		"is_folder"=>false,"display_name"=>gettext("Locator")),
			array("name"=>"dNIPSubnet",			"icon"=>"dhcp/dhcp-subnet.png",			"is_folder"=>true,"display_name"=>gettext("Subnet")),
			array("name"=>"dNIPSubnetAddressRange",		"icon"=>"novell/dnip-subnet-address-range.png",	"is_folder"=>false,"display_name"=>gettext("Subnet Address Range")),
			array("name"=>"dNIPSubnetPool",			"icon"=>"dhcp/dhcp-shared-network.png",		"is_folder"=>false,"display_name"=>gettext("Subnet Pool"))
			);

		// Display layouts
		$ldap_server->add_display_layout("dNIPDHCPServer",array(
			array("section_name"=>gettext("NetWare DHCP Server Object"),
				"attributes"=>array(
					array("cn",				gettext("Name"),				"generic24.png"),
					array("dnipDHCPVersion",		gettext("Version"),				"generic24.png")
					)
				)
			));

		$ldap_server->add_display_layout("dNIPDNSZone",array(
			array("section_name"=>gettext("DNS Zone"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),				"novell/dnip-dns-zone.png"),
					array("dnipSecondaryZone",		gettext("Secondary Zone"),			"generic24.png")
					)
				),
			array("section_name"=>gettext("Start of Authority Record"),"new_row"=>true,"width"=>"50%",
				"attributes"=>array(
					array("dnipZoneDomainName",		gettext("Fully Qualified Domain Name"),		"novell/dnip-dns-zone.png"),
					array("dnipSOAAdminMailbox",		gettext("Admin Mailbox"),			"mail.png"),
					array("dnipSOAZoneMaster",		gettext("Zone Master"),				"server.png"),
					array("dnipSOASerial",			gettext("Zone Serial Number"),			"generic24.png"),
					array("dnipSOARefresh",			gettext("Refresh Interval (s)"),		"time.png"),
					array("dnipSOARetry",			gettext("Refresh Retry Interval (s)"),		"time.png"),
					array("dnipSOAMinimum",			gettext("Minimum Record TTL for Zone (s)"),	"time.png"),
					array("dnipSOAExpire",			gettext("Authority Expiry Time (s)"),		"time.png")
					)
				),
                        array("section_name"=>gettext("DNS Records"),"new_row"=>true,
                                "attributes"=>array(
                                        array("__CHILD_OBJECTS__")
                                        )
                                )
			));

		$ldap_server->add_display_layout("dNIPDNSKey",array(
			array("section_name"=>gettext("DNS Transaction Signature (TSIG) Key"),"new_row"=>true,
				"attributes"=>array(
					array("dnipDNSKeyAlgorithm",		gettext("Algorithm"),				"generic24.png"),
					array("dnipDNSKeySecret",		gettext("Secret"),				"generic24.png"),
					)
				),
			array("section_name"=>gettext("Comments"),"new_row"=>true,
				"attributes"=>array(
					array("dnipComment")
					)
				)
			));

		$ldap_server->add_display_layout("dNIPDNSRRset",array(
			array("section_name"=>gettext("DNS Resource Record Set"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),				"document-series.png"),
					array("dnipDNSDomainName",		gettext("DNS Domain Name"),			"novell/dnip-dns-zone.png"),
					array("dnipAliasedObjectName",		gettext("Associated NDS Object"),		"alias.png"),
					array("dnipRRStatus",			gettext("Status"),				"generic24.png"),
					array("description",			gettext("Comments"),				"description.png"),
					)
				),
			array("section_name"=>gettext("Resource Records"),"new_row"=>true,
				"attributes"=>array(
					array("dnipRR"),
					)
				)
			));

		$ldap_server->add_display_layout("dNIPLocator",array(
			array("section_name"=>gettext("DNS/DHCP Group Object"),
				"attributes"=>array(
					array("dnipGroupReference"),
					)
				),
			array("section_name"=>gettext("DNS Objects"),"new_row"=>true,
				"attributes"=>array(
					array("dnipDNSZones",			gettext("Zones"),				"generic24.png")
					)
				),
			array("section_name"=>gettext("DHCP Objects"),"new_row"=>true,
				"attributes"=>array(
					array("dnipSubnetAttr",			gettext("Subnet Attributes"),			"generic24.png")
					)
				)
			));

		$ldap_server->add_display_layout("dNIPSubnet",array(
			array("section_name"=>gettext("NetWare DNS/DHCP Subnet"),
				"attributes"=>array(
					array("dnipSubnetPoolReference",	gettext("Subnet Pool Reference"),		"generic24.png"),
					array("dnipSubnetAddress",		gettext("Subnet Address"),			"generic24.png"),
					array("dnipSubnetMask",			gettext("Subnet Mask"),				"generic24.png"),
					array("dnipSubnetType",			gettext("Subnet Type"),				"generic24.png"),
					array("dnipLeaseTime",			gettext("IP Address Lease Time (s)"),		"time.png"),
					array("dnipDomainName",			gettext("Domain Name"),				"generic24.png")
				//	array("dnipBootParameter",		gettext("Boot Parameters"),			"generic24.png")
					)
				),
			array("section_name"=>gettext("Comments"),"new_row"=>true,
				"attributes"=>array(
					array("dnipComment")
					)
				),
			));

		$ldap_server->add_display_layout("dNIPSubnetPool",array(
			array("section_name"=>gettext("NetWare DNS/DHCP Subnet Pool"),
				"attributes"=>array(
					array("dnipSubnetType",			gettext("Type"),				"generic24.png"),
					)
				),
			array("section_name"=>gettext("Subnet Objects"),"new_row"=>true,
				"attributes"=>array(
					array("dnipSubnetAttr")
					)
				),
			));

		// Auxiliary class display layouts

		$ldap_server->add_display_layout("dnipDNSDHCPServerVersion",array(
			array("section_name"=>gettext("NetWare DNS/DHCP Server Versions"),
				"attributes"=>array(
					array("dnipDNSServerVersion",			gettext("DNS Server Version"),		"generic24.png"),
					array("dnipDHCPServerVersion",			gettext("DHCP Server Version"),		"generic24.png"),
					)
				),
			));

		parent::__construct($ldap_server);
	}
}
?>
