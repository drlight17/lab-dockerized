<?php
/** Novell Apache HTTP Server schema (partial) */

class novell_apache_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"apchadmn-ConfigurationInfo",	"data_type"=>"text_area",	"display_name"=>gettext("Apache HTTP Server Configuration Info")),
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"apchadmnConfiguration",		"icon"=>"novell/apache-server.png",		"class_type"=>"auxiliary"),
			array("name"=>"apchadmnConfigurationBlock",	"icon"=>"novell/apache-config-block.png",	"is_folder"=>false,"required_attribs"=>"apchadmn-BlockType,apchadmn-TypeName"),
			array("name"=>"apchadmnModule",			"icon"=>"novell/apache-module.png",		"is_folder"=>true,"required_attribs"=>"apchadmn-ModuleFileName,apchadmn-ModuleObjectFile,apchadmn-ModuleSymbolName,apchadmn-TypeName"),
			array("name"=>"apchadmnVirtualHost",		"icon"=>"novell/apache-vhost.png",		"is_folder"=>true,"required_attribs"=>"apchadmn-TypeName"),
			array("name"=>"apchadmnServer",			"icon"=>"novell/apache-server.png",		"is_folder"=>false,"required_attribs"=>"apchadmn-TypeName")
			);

		// Display layouts

		$ldap_server->add_display_layout("apchadmnConfigurationBlock",array(
			array("section_name"=>gettext("Apache HTTP Server Configuration Block"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),			"novell/apache-config-block.png"),
					array("apchadmn-TypeName",		gettext("Type Name"),			"object.png"),
					array("apchadmn-Scope",			gettext("Scope"),			"folder.png"),
					array("apchadmn-BlockType",		gettext("Block Type"),			"generic24.png")
					)
				),
			array("section_name"=>gettext("Child Objects"),"new_row"=>true,
				"attributes"=>array(
					array("__CHILD_OBJECTS__")
					)
				)
			));

		$ldap_server->add_display_layout("apchadmnModule",array(
			array("section_name"=>gettext("Apache HTTP Server Module"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),			"generic24.png"),
					array("apchadmn-TypeName",		gettext("Type Name"),			"object.png"),
					array("apchadmn-ModuleDisable",		gettext("Disabled"),			"generic24.png"),
					array("apchadmn-ModuleFileName",	gettext("File Name"),			"generic24.png"),
					array("apchadmn-ModuleObjectFile",	gettext("Object File"),			"generic24.png"),
					array("apchadmn-ModuleSymbolName",	gettext("Symbol Name"),			"generic24.png")
					)
				)
			));

		$ldap_server->add_display_layout("apchadmnServer",array(
			array("section_name"=>gettext("Apache HTTP Server Configuration"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),			"novell/apache-server.png"),
					array("apchadmn-TypeName",		gettext("Type Name"),			"object.png")
					)
				),
			array("section_name"=>gettext("Child Objects"),"new_row"=>true,
				"attributes"=>array(
					array("__CHILD_OBJECTS__")
					)
				)
			));

		// Auxiliary class display layouts

		$ldap_server->add_display_layout("apchadmnConfiguration",array(
			array("section_name"=>gettext("Apache Configuration Statements"),"new_row"=>true,
				"attributes"=>array(
					array("apchadmn-ConfigurationInfo")
					)
				)
			));

		parent::__construct($ldap_server);
	}

	/** Assign default values for apchadmnServer attributes */

	function populate_for_create_apchadmnServer(&$ldap_server,&$entry)
	{
		$this->add_attrib_value($ldap_server,$entry,"apchadmn-TypeName","apchadmnServer");
	}

	/** Assign default values for apchadmnConfigurationBlock attributes */

	function populate_for_create_apchadmnConfigurationBlock(&$ldap_server,&$entry)
	{
		$this->add_attrib_value($ldap_server,$entry,"apchadmn-TypeName","apchadmnConfigurationBlock");
	}
}
?>
