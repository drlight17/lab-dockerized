<?php
/** NDS Catalog Services schema (partial) */

class novell_catalog_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Object classes
		$this->object_schema = array(
			array("name"=>"nDSCatCatalog",			"icon"=>"generic24.png",		"class_type"=>"abstract","display_name"=>gettext("Catalog"),"parent_class"=>"Resource,top"),
			array("name"=>"nDSCatMasterCatalog",		"icon"=>"novell/catalog-master.png",	"is_folder"=>false,"display_name"=>gettext("Master Catalog"),"parent_class"=>"nDSCatCatalog"),
			array("name"=>"nDSCatSlaveCatalog",		"icon"=>"novell/catalog-slave.png",	"is_folder"=>false,"display_name"=>gettext("Slave Catalog"),"parent_class"=>"nDSCatCatalog")
			);

                parent::__construct($ldap_server);
        }
}
?>
