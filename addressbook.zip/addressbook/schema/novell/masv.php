<?php
/** Novell Mandatory Access Control Service (MASV) schema */

class novell_masv_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		$this->attribute_schema = array(
			array("name"=>"masvAuthorizedRange",		"data_type"=>"download_list",	"display_name"=>gettext("Authorized Range")),
			array("name"=>"masvClearanceNames",		"data_type"=>"download_list",	"display_name"=>gettext("Clearance Names")),
			array("name"=>"masvDefaultRange",		"data_type"=>"download",	"display_name"=>gettext("Default Range")),
			array("name"=>"masvDomainPolicy",		"data_type"=>"download",	"display_name"=>gettext("Domain Policy")),
			array("name"=>"masvLabel",			"data_type"=>"download",	"display_name"=>gettext("Label")),
			array("name"=>"masvLabelIntegrityCategoryNames","data_type"=>"download_list",	"display_name"=>gettext("Integrity Category Names")),
			array("name"=>"masvLabelIntegrityLevelNames",	"data_type"=>"download_list",	"display_name"=>gettext("Integrity Level Names")),
			array("name"=>"masvLabelNames",			"data_type"=>"download_list",	"display_name"=>gettext("Label Names")),
			array("name"=>"masvLabelSecrecyCategoryNames",	"data_type"=>"download_list",	"display_name"=>gettext("Secrecy Category Names")),
			array("name"=>"masvLabelSecrecyLevelNames",	"data_type"=>"download_list",	"display_name"=>gettext("Secrecy Level Names")),
			array("name"=>"masvNDSAttributeLabels",		"data_type"=>"download_list",	"display_name"=>gettext("NDS Attribute Labels")),
			array("name"=>"masvPolicyDN",			"data_type"=>"dn",		"display_name"=>gettext("MASV Policy")),
			array("name"=>"masvPolicyUpdate",		"data_type"=>"text",		"display_name"=>gettext("Policy Update")),
			array("name"=>"masvProposedLabel",		"data_type"=>"download",	"display_name"=>gettext("Proposed Label"))
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"mASVSecurityPolicy","icon"=>"novell/security-policy.png","is_folder"=>false,"display_name"=>gettext("Security Policy")),
			);

		// Display layouts

		$ldap_server->add_display_layout("mASVSecurityPolicy",array(
			array("section_name"=>gettext("Security Policy"),
				"attributes"=>array(
					array("masvPolicyUpdate",		gettext("Policy Update"),			"generic24.png"),
					array("masvLabelNames",			gettext("Label Names"),				"generic24.png"),
					array("masvClearanceNames",		gettext("Clearance Names"),			"generic24.png")
					)
				),
			array("section_name"=>gettext("Secrecy Categories"),"new_row"=>true,"width"=>"50%",
				"attributes"=>array(
					array("masvLabelSecrecyCategoryNames")
					)
				),
			array("section_name"=>gettext("Secrecy Levels"),
				"attributes"=>array(
					array("masvLabelSecrecyLevelNames")
					)
				),
			array("section_name"=>gettext("Integrity Categories"),"new_row"=>true,"width"=>"50%",
				"attributes"=>array(
					array("masvLabelIntegrityCategoryNames")
					)
				),
			array("section_name"=>gettext("Integrity Levels"),
				"attributes"=>array(
					array("masvLabelIntegrityLevelNames")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
