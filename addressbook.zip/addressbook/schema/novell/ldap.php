<?php
/** Novell LDAP Agent for Novell eDirectory schema */

class novell_ldap_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		/** Custom enum data type for representing options for LDAP referral behaviour */

		$ldap_server->add_enum_data_type("ldap_ref_usage",
			array(
				array("value"=>"0",	"display_name"=>gettext("Always Chain")),
				array("value"=>"1",	"display_name"=>gettext("Prefer Chaining")),
				array("value"=>"2",	"display_name"=>gettext("Prefer Referrals")),
				array("value"=>"3",	"display_name"=>gettext("Always Refer"))
				)
			);

		/** Custom enum data type for representing certificate-based client verification requirements */

		$ldap_server->add_enum_data_type("ldap_client_vfry",
			array(
				array("value"=>"0",	"display_name"=>gettext("Client Certificate Not Required")),
				array("value"=>"1",	"display_name"=>gettext("Require Valid Client Certificate When Sent")),
				array("value"=>"2",	"display_name"=>gettext("Always Require Valid Client Certificate"))
				)
			);

		// Attributes

		$this->attribute_schema = array(
			array("name"=>"extensionInfo",				"data_type"=>"text_list",	"display_name"=>gettext("LDAP Extension Plugin List")),
			array("name"=>"filteredReplicaUsage",			"data_type"=>"yes_no_integer",	"display_name"=>gettext("Use Filtered Replicas for Searches")),
			array("name"=>"ldapAllowClearTextPassword",		"data_type"=>"yes_no",		"display_name"=>gettext("LDAP Allow Clear Text Password")),
			array("name"=>"ldapAnonymousIdentity",			"data_type"=>"dn_list",		"display_name"=>gettext("LDAP Anonymous Identity")),
			array("name"=>"ldapAttributeList",			"data_type"=>"text_list",	"display_name"=>gettext("LDAP Attribute List")),
			array("name"=>"ldapAttributeMap",			"data_type"=>"download_list",	"display_name"=>gettext("LDAP Attribute Map v11")),		// legacy
			array("name"=>"lDAPBackupLogFilename",			"data_type"=>"text",		"display_name"=>gettext("Backup Log Filename")),
			array("name"=>"ldapChainSecureRequired",		"data_type"=>"yes_no",		"display_name"=>gettext("Use Secure NCP For Chaining")),
			array("name"=>"ldapClassList",				"data_type"=>"text_list",	"display_name"=>gettext("LDAP Class List")),
			array("name"=>"ldapClassMap",				"data_type"=>"download_list",	"display_name"=>gettext("LDAP Class Map v11")),			// legacy
			array("name"=>"ldapConfigVersion",			"data_type"=>"text",		"display_name"=>gettext("LDAP Configuration Version")),
			array("name"=>"ldapDerefAlias",				"data_type"=>"yes_no",		"display_name"=>gettext("Dereference Aliases")),
			array("name"=>"ldapDerefAliasOnAuth",			"data_type"=>"yes_no",		"display_name"=>gettext("Dereference Aliases on Authentication")),
			array("name"=>"ldapEnableMonitorEvents",		"data_type"=>"yes_no",		"display_name"=>gettext("Enable Monitor Events")),
			array("name"=>"ldapEnablePSearch",			"data_type"=>"yes_no",		"display_name"=>gettext("Enable Persistent Search")),
			array("name"=>"ldapEnableSSL",				"data_type"=>"yes_no",		"display_name"=>gettext("Enable TLS")),
			array("name"=>"ldapEnableTCP",				"data_type"=>"yes_no",		"display_name"=>gettext("Enable TCP (non-TLS)")),
			array("name"=>"ldapGroupDN",				"data_type"=>"dn_list",		"display_name"=>gettext("LDAP Group DN")),
			array("name"=>"ldapHostServer",				"data_type"=>"dn_list",		"display_name"=>gettext("LDAP Server Host")),
			array("name"=>"ldapIgnorePSearchLimitsForEvents",	"data_type"=>"yes_no",		"display_name"=>gettext("Ignore Persistent Search Limits for Events")),
			array("name"=>"ldapInterfaces",				"data_type"=>"text_list",	"display_name"=>gettext("Listening Interface URLs")),
			array("name"=>"ldapKeyMaterialName",			"data_type"=>"text",		"display_name"=>gettext("Server Certificate Name")),
			array("name"=>"ldapLBURPNumWriterThreads",		"data_type"=>"text",		"display_name"=>gettext("Number of LBURP Writer Threads")),
			array("name"=>"lDAPLogFilename",			"data_type"=>"text",		"display_name"=>gettext("Log Filename")),
			array("name"=>"lDAPLogLevel",				"data_type"=>"text",		"display_name"=>gettext("Log Level")),
			array("name"=>"lDAPLogSizeLimit",			"data_type"=>"text",		"display_name"=>gettext("Log Size Limit")),
			array("name"=>"ldapMaximumMonitorEventsLoad",		"data_type"=>"text",		"display_name"=>gettext("Maximum Event Monitoring Load (operations)")),
			array("name"=>"ldapMaximumPSearchOperations",		"data_type"=>"text",		"display_name"=>gettext("Maximum Number of Concurrent Persistent Search Operations")),
			array("name"=>"ldapNonStdAllUserAttrsMode",		"data_type"=>"yes_no",		"display_name"=>gettext("Non-Standard All User Attributes Mode")),
			array("name"=>"ldapOtherReferralUsage",			"data_type"=>"ldap_ref_usage",	"display_name"=>gettext("Use of Referrals for Other eDirectory Operations")),
			array("name"=>"ldapReferral",				"data_type"=>"text",		"display_name"=>gettext("Default Referral URL")),
			array("name"=>"ldapSearchReferralUsage",		"data_type"=>"ldap_ref_usage",	"display_name"=>gettext("Use of Referrals for eDirectory Searches")),
			array("name"=>"ldapServerBindLimit",			"data_type"=>"text",		"display_name"=>gettext("Maximum Number of Concurrent Binds")),
			array("name"=>"ldapServerDN",				"data_type"=>"dn_list",		"display_name"=>gettext("LDAP Server DN")),
			array("name"=>"ldapServerIdleTimeout",			"data_type"=>"text",		"display_name"=>gettext("Server Idle Timeout")),
			array("name"=>"ldapServerList",				"data_type"=>"dn_list",		"display_name"=>gettext("LDAP Server List")),
			array("name"=>"ldapSSLPort",				"data_type"=>"text",		"display_name"=>gettext("Encrypted LDAP/SSL Port Number")),
			array("name"=>"ldapStdCompliance",			"data_type"=>"yes_no_integer",	"display_name"=>gettext("Single Level Searches Return Subordinate Referrals")),
			array("name"=>"lDAPSuffix",				"data_type"=>"dn",		"display_name"=>gettext("Searchable/Accessible Suffix")),	// legacy
			array("name"=>"ldapTCPPort",				"data_type"=>"text",		"display_name"=>gettext("Non-Encrypted LDAP Port Number")),
			array("name"=>"ldapTLSRequired",			"data_type"=>"yes_no",		"display_name"=>gettext("TLS Required")),
			array("name"=>"ldapTLSTrustedRootContainer",		"data_type"=>"text_list",	"display_name"=>gettext("Trusted Root Container NDS Path")),
			array("name"=>"ldapTLSVerifyClientCertificate",		"data_type"=>"ldap_client_vfry","display_name"=>gettext("Client Certificate Verification Requirements")),
			array("name"=>"ldapTransitionBackLink",			"data_type"=>"dn",		"display_name"=>gettext("Transition Backlink")),
			array("name"=>"lDAPUDPPort",				"data_type"=>"text",		"display_name"=>gettext("Connectionless LDAP (UDP) Port Number")),
			array("name"=>"nonStdClientSchemaCompatMode",		"data_type"=>"yes_no",		"display_name"=>gettext("Non-Standard Client Schema Compatibility Mode")),
			array("name"=>"searchSizeLimit",			"data_type"=>"text",		"display_name"=>gettext("Maximum Number of Search Results")),
			array("name"=>"searchTimeLimit",			"data_type"=>"text",		"display_name"=>gettext("Maximum Search Time (s)")),
			array("name"=>"sslEnableMutualAuthentication",		"data_type"=>"yes_no",		"display_name"=>gettext("Enable TLS Mutual Authentication")),
			array("name"=>"transitionGroupDN",			"data_type"=>"dn",		"display_name"=>gettext("Transition Group DN")),
			array("name"=>"referralExcludeFilter",			"data_type"=>"text_list",	"display_name"=>gettext("Referral Exclude Filter")),
			array("name"=>"referralIncludeFilter",			"data_type"=>"text_list",	"display_name"=>gettext("Referral Include Filter")),

			// The following attributes contain integers which are to be interpretted as bit fields
			// (TODO: not yet supported by LDAP Address Book)
			array("name"=>"ldapBindRestrictions",			"data_type"=>"text",		"display_name"=>gettext("Bind Restrictions")),
			array("name"=>"ldapDefaultReferralBehavior",		"data_type"=>"text",		"display_name"=>gettext("Conditions Which Return Default Referral")),
			array("name"=>"ldapTraceLevel",				"data_type"=>"text",		"display_name"=>gettext("Tracing Options")),

			// E-mail address attribute for inetOrgPerson (eDirectory User) object class (compare RFC4524)
			array("name"=>"mail",					"data_type"=>"text","display_name"=>gettext("Internet EMail Address"))
			);

		// employeeNumber is also defined in this schema - duplicated in nov_inet

		// Object classes
		$this->object_schema = array(
			array("name"=>"ldapGroup",			"icon"=>"novell/ldap-group.png",	"is_folder"=>false,"display_name"=>gettext("LDAP Group")),
			array("name"=>"ldapServer",			"icon"=>"ldap-server.png",		"is_folder"=>false,"display_name"=>gettext("LDAP Server"))
			);

		// Display layouts
		$ldap_server->add_display_layout("ldapServer",array(
			array("section_name"=>gettext("LDAP Server Details"),"new_row"=>true,
				"attributes"=>array(
					array("version",				gettext("Product Version"),				"generic24.png"),
					array("ldapHostServer",				gettext("Host"),					"generic24.png"),
					array("ldapGroupDN",				gettext("LDAP Group"),					"generic24.png"),
					)
				),
			array("section_name"=>gettext("Non-Standard Behaviors"),"new_row"=>true,
				"attributes"=>array(
					array("ldapDerefAliasOnAuth",			gettext("Dereference Aliases when Resolving Names for Authentication"),"generic24.png"),
					array("ldapDerefAlias",				gettext("Dereference Aliases when Resolving Names on All Operations"),"generic24.png"),
					)
				),
			array("section_name"=>gettext("Transport Layer Security (TLS/SSL)"),"new_row"=>true,
				"attributes"=>array(
					array("ldapKeyMaterialName",			gettext("Server Certificate"),				"generic24.png"),
					array("ldapTLSVerifyClientCertificate",		gettext("Client Certificate"),				"generic24.png"),
					array("ldapTLSRequired",			gettext("Require TLS for All Operations"),		"generic24.png"),
					)
				),
			array("section_name"=>gettext("Ports"),"new_row"=>true,
				"attributes"=>array(
					array("ldapEnableSSL",				gettext("Enable Encrypted Port"),			"generic24.png"),
					array("ldapSSLPort",				gettext("Encrypted Port"),				"generic24.png"),
					array("ldapEnableTCP",				gettext("Enable Non-Encrypted Port"),			"generic24.png"),
					array("ldapTCPPort",				gettext("Non-Encrypted Port"),				"generic24.png"),
					)
				),
			array("section_name"=>gettext("LDAP Bulk Update/Replication Protocol (LBURP)"),"new_row"=>true,
				"attributes"=>array(
					array("ldapLBURPNumWriterThreads",		gettext("Number of Writer Threads"),			"generic24.png"),
					)
				),
			array("section_name"=>gettext("LDAP Server"),"new_row"=>true,
				"attributes"=>array(
					array("ldapInterfaces",				gettext("LDAP Interfaces"),				"generic24.png"),
					array("ldapServerBindLimit",			gettext("Concurrent Bind Limit"),			"generic24.png"),
					array("ldapServerIdleTimeout",			gettext("Idle Timeout (s)"),				"time.png"),
					array("ldapBindRestrictions",			gettext("Bind Restrictions"),				"generic24.png"),
					)
				),
			array("section_name"=>gettext("Searches"),"new_row"=>true,
				"attributes"=>array(
					array("ldapEnablePSearch",			gettext("Enable Persistent Search"),			"generic24.png"),
					array("ldapMaximumPSearchOperations",		gettext("Maximum Concurrent Persistent Searches"),	"generic24.png"),
					array("ldapIgnorePSearchLimitsForEvents",	gettext("Ignore Size and Time Limits when Monitoring Persistent Search Events"),"generic24.png"),
					array("searchTimeLimit",			gettext("Search Time Limit"),				"generic24.png"),
					array("searchSizeLimit",			gettext("Result Size Limit (Number of Entries)"),	"generic24.png"),
					array("ldapNonStdAllUserAttrsMode",		gettext("Return Operational Attributes when all User Attributes are Requested"),"generic24.png"),
					array("nonStdClientSchemaCompatMode",		gettext("Enable old ADSI and Netscape Schema Output"),	"generic24.png"),
					)
				),
			array("section_name"=>gettext("Event Monitoring and Tracing"),"new_row"=>true,
				"attributes"=>array(
					array("ldapEnableMonitorEvents",		gettext("Enable Event Monitoring"),			"generic24.png"),
					array("ldapMaximumMonitorEventsLoad",		gettext("Maximum Event Monitoring Load (operations)"),	"generic24.png"),
					array("ldapTraceLevel",				gettext("Tracing Options"),				"generic24.png"),
					)
				),
			array("section_name"=>gettext("Referrals"),"new_row"=>true,
				"attributes"=>array(
					array("ldapReferral",				gettext("Default Referral URL"),			"generic24.png"),
					array("ldapDefaultReferralBehavior",		gettext("Conditions Which Return Default Referral"),	"generic24.png"),
					array("ldapSearchReferralUsage",		gettext("Use Referrals for Searches"),			"generic24.png"),
					array("ldapOtherReferralUsage",			gettext("Use Referrals for Other eDirectory Operations"),"generic24.png")
					)
				),

			/** @todo Decode extensionInfo array - list of OIDs */

			/*
			array("section_name"=>gettext("LDAP Extensions List"),"new_row"=>true,
				"attributes"=>array(
					array("extensionInfo"),
					)
				),
			*/

			/** @todo Decode filteredReplicaUsage */

			/*
			array("section_name"=>gettext("Filtered Replica Usage"),"new_row"=>true,
				"attributes"=>array(
					array("filteredReplicaUsage"),
					)
				),
			*/

			array("section_name"=>gettext("Config Version"),"new_row"=>true,
				"attributes"=>array(
					array("ldapConfigVersion")
					)
				)
			));

		$ldap_server->add_display_layout("ldapGroup",array(
			array("section_name"=>gettext("LDAP Server List"),"new_row"=>true,
				"attributes"=>array(
					array("ldapServerList"),
					)
				),
			array("section_name"=>gettext("Authentication Options"),"new_row"=>true,
				"attributes"=>array(
					array("ldapAnonymousIdentity",		gettext("Proxy User (Anonymous Identity)"),			"generic24.png"),
					array("ldapAllowClearTextPassword",	gettext("Require TLS for Simple Binds with Password"),		"generic24.png")
					)
				),
			array("section_name"=>gettext("Referrals"),"new_row"=>true,
				"attributes"=>array(
					array("ldapReferral",			gettext("Default Referral URL"),				"generic24.png"),
					array("ldapDefaultReferralBehavior",	gettext("Conditions Which Return Default Referral"),		"generic24.png"),
					array("ldapSearchReferralUsage",	gettext("Use of Referrals for eDirectory Searches"),		"generic24.png"),
					array("ldapOtherReferralUsage",		gettext("Use of Referrals for Other eDirectory Operations"),	"generic24.png")
					)
				),
			array("section_name"=>gettext("NDS to LDAP Object Mappings"),"new_row"=>true,
				"attributes"=>array(
					array("ldapClassList")
					)
				),
			array("section_name"=>gettext("NDS to LDAP Attribute Mappings"),"new_row"=>true,
				"attributes"=>array(
					array("ldapAttributeList")
					)
				),
			array("section_name"=>gettext("Config Version"),"new_row"=>true,
				"attributes"=>array(
					array("ldapConfigVersion")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
