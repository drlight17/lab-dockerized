<?php
/** Novell BorderManager Firewall Server schema (partial) */

class novell_fws_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"fwsServiceList",		"data_type"=>"text_list",	"display_name"=>gettext("Service List"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"fwsAuxFiltServer",		"icon"=>"generic24.png",		"class_type"=>"auxiliary"),
			array("name"=>"fwsPacketForwardFilter",		"icon"=>"generic24.png",		"is_folder"=>false,"contained_by"=>"fwsRuleContainer"),
			array("name"=>"fwsRoutingFilter",		"icon"=>"generic24.png",		"is_folder"=>false,"contained_by"=>"fwsRuleContainer"),
			array("name"=>"fwsRuleContainer",		"icon"=>"novell/fws-rule-container.png","is_folder"=>false,"contained_by"=>"Organization,organizationalUnit,domain,Locality,Country")
			);

		// Display layouts

                $ldap_server->add_display_layout("fwsRuleContainer",array(
                        array("section_name"=>gettext("BorderManager Filering Rule Container"),
                                "attributes"=>array(
                                        array("cn",                             gettext("Object Name"),                 "novell/fwsrulecontainer.png"),
                                        array("description",                    gettext("Description"),                 "description.png")
                                        )
                                ),
                        array("section_name"=>gettext("Service List"),"new_row"=>true,
                                "attributes"=>array(
                                        array("fwsServiceList")
                                        )
                                ),
                        array("section_name"=>gettext("Child Objects"),"new_row"=>true,
                                "attributes"=>array(
                                        array("__CHILD_OBJECTS__")
                                        )
                                )
                        ));

                parent::__construct($ldap_server);
        }
}
?>
