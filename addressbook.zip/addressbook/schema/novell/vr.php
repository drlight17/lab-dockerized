<?php
/** Novell DirXML schema (partial) */

class novell_vr_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"DirXML-Act1",			"data_type"=>"download"),	// license activation data?
			array("name"=>"DirXML-Act2",			"data_type"=>"download"),	// timestamp for 90 day eval activation start?
			array("name"=>"DirXML-ApplicationSchema",	"data_type"=>"text_area"),
			array("name"=>"DirXML-DriverImage",		"data_type"=>"image"),
			array("name"=>"DirXML-JavaModule",		"data_type"=>"text"),
			array("name"=>"DirXML-MappingRule",		"data_type"=>"dn"),
			array("name"=>"DirXML-ServerList",		"data_type"=>"dn_list"),
			array("name"=>"XmlData",			"data_type"=>"text_area")
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"StyleSheet",				"icon"=>"generic24.png",		"is_folder"=>false),
			array("name"=>"DirXML-Driver",				"icon"=>"novell/dirxml-driver.png",	"is_folder"=>true),
			array("name"=>"DirXML-DriverSet",			"icon"=>"novell/dirxml-driverset.png",	"is_folder"=>true),
			array("name"=>"DirXML-GlobalConfigDef",			"icon"=>"generic24.png",		"is_folder"=>false),
			array("name"=>"DirXML-Job",				"icon"=>"novell/dirxml-job.png",	"is_folder"=>true),
			array("name"=>"DirXML-Library",				"icon"=>"novell/dirxml-library.png",	"is_folder"=>true),
			array("name"=>"DirXML-PasswordGeneration",		"icon"=>"generic24.png",		"class_type"=>"auxiliary"),
			array("name"=>"DirXML-PasswordSyncStatusUser",		"icon"=>"generic24.png",		"class_type"=>"auxiliary"),
			array("name"=>"DirXML-PkgItemAux",			"icon"=>"generic24.png",		"class_type"=>"auxiliary"),
			array("name"=>"DirXML-PkgTargetAux",			"icon"=>"generic24.png",		"class_type"=>"auxiliary"),
			array("name"=>"DirXML-Publisher",			"icon"=>"novell/dirxml-publisher.png",	"is_folder"=>true),
			array("name"=>"DirXML-Resource",			"icon"=>"novell/dirxml-resource.png",	"is_folder"=>false),
			array("name"=>"DirXML-Rule",				"icon"=>"novell/dirxml-rule.png",	"is_folder"=>false),
			array("name"=>"DirXML-StyleSheet",			"icon"=>"novell/dirxml-stylesheet.png",	"is_folder"=>false),
			array("name"=>"DirXML-Subscriber",			"icon"=>"novell/dirxml-subscriber.png",	"is_folder"=>true),
			array("name"=>"DirXML-TelemetryJob",			"icon"=>"generic24.png",		"class_type"=>"auxiliary"),
			array("name"=>"DirXML-uiExtensions",			"icon"=>"generic24.png",		"class_type"=>"auxiliary")
			);

		// Display layouts

		$ldap_server->add_display_layout("DirXML-DriverSet",array(
			array("section_name"=>gettext("DirXML Driver Set"),
				"attributes"=>array(
					array("cn",				gettext("Driver Set Name"),			"novell/dirxml-driverset.png"),
					array("DirXML-ServerList",		gettext("Servers Using This Driver Set"),	"alias.png")

					// also present: DirXML-Act1, DirXML-Act2

					)
				)
			));

		$ldap_server->add_display_layout("DirXML-Driver",array(
			array("section_name"=>gettext("DirXML Driver"),
				"attributes"=>array(
					array("cn",				gettext("Driver Name"),				"novell/dirxml-driver.png"),
					array("DirXML-MappingRule",		gettext("Mapping Rule"),			"alias.png"),
					array("DirXML-JavaModule",		gettext("Java Module"),				"java.png"),

					// also present: DirXML-Act1, DirXML-Act2

					)
				),
			array("section_name"=>gettext("Driver Image"),"width"=>"50%",
				"attributes"=>array(
					array("DirXML-DriverImage")
					)
				),
			array("section_name"=>gettext("Application Schema"),"new_row"=>true,
				"attributes"=>array(
					array("DirXML-ApplicationSchema")
					)
				)
			));

		$ldap_server->add_display_layout("DirXML-Rule",array(
			array("section_name"=>gettext("DirXML Rule Object"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),				"novell/dirxml-rule.png"),
					)
				),
			array("section_name"=>gettext("XML Data"),"new_row"=>true,
				"attributes"=>array(
					array("XmlData")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
