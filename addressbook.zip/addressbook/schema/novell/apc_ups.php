<?php
/** APC UPS schema */

class novell_apc_ups_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes
		$this->attribute_schema = array(
			array("name"=>"aPCUPSPCCOMPort",		"data_type"=>"text",		"display_name"=>gettext("COM Port")),
			array("name"=>"aPCUPSPCCOMState",		"data_type"=>"yes_no",		"display_name"=>gettext("COM State")),
			array("name"=>"aPCUPSPCFirmwareNumber",		"data_type"=>"text",		"display_name"=>gettext("Firmware Revision Number")),
			array("name"=>"aPCUPSPCHostServer",		"data_type"=>"dn",		"display_name"=>gettext("Host Server")),
			array("name"=>"aPCUPSPCReplaceBattery",		"data_type"=>"text",		"display_name"=>gettext("Battery Status")),
			array("name"=>"aPCUPSPCSelfTest",		"data_type"=>"text",		"display_name"=>gettext("Last Self Test")),
			array("name"=>"aPCUPSPCSerialNumber",		"data_type"=>"text",		"display_name"=>gettext("Serial Number")),
			array("name"=>"aPCUPSPCUpflag",			"data_type"=>"yes_no",		"display_name"=>gettext("NLM Status")),
			array("name"=>"aPCUPSPCUPSModel",		"data_type"=>"text",		"display_name"=>gettext("UPS Model")),
			array("name"=>"aPCUPSPCUPSState",		"data_type"=>"text",		"display_name"=>gettext("UPS State"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"aPCUPSPCUPS",			"icon"=>"novell/ups.png",		"is_folder"=>false,"display_name"=>gettext("APC UPS"),"required_attribs"=>"aPCUPSPCHostServer","contained_by"=>"organization,organizationalUnit")
			);

		// Display layouts

		$ldap_server->add_display_layout("aPCUPSPCUPS",array(
			array("section_name"=>gettext("APC UPS"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),		"novell/ups.png"),
					array("aPCUPSPCHostServer",		gettext("Host Server"),		"alias.png"),
					array("aPCUPSPCUpflag",			gettext("Software Running"),	"generic24.png"),
					array("aPCUPSPCCOMState",		gettext("UPS State"),		"generic24.png"),
					array("aPCUPSPCUPSModel",		gettext("UPS Model"),		"generic24.png"),
					array("aPCUPSPCSerialNumber",		gettext("Serial Number"),	"generic24.png"),
					array("aPCUPSPCFirmwareNumber",		gettext("Firmware Revision"),	"generic24.png"),
					array("aPCUPSPCReplaceBattery",		gettext("Battery Status"),	"generic24.png"),
					array("aPCUPSPCSelfTest",		gettext("Last Self Test"),	"generic24.png"),
					array("aPCUPSPCCOMPort",		gettext("COM Board Type, Number, Port"),"generic24.png")

				//	array("publicKey",			gettext("Public Key"),		"generic24.png"),
				//	array("privateKey",			gettext("Private Key"),		"generic24.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}

	/** Assign default values for aPCUPSPCUPS attributes */

	function populate_for_create_aPCUPSPCUPS(&$ldap_server,&$entry)
	{
		$this->add_attrib_value($ldap_server,$entry,"cn","servername_ups");
		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCHostServer","");

		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCUpflag","FALSE");
		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCCOMState","FALSE");

		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCUPSModel","n/a");
		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCSerialNumber","n/a");
		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCFirmwareNumber","n/a");
		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCReplaceBattery","n/a");
		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCSelfTest","n/a");
		$this->add_attrib_value($ldap_server,$entry,"aPCUPSPCCOMPort","n/a");
	}
}
?>
