<?php
/** Novell ZENworks Desktop Management Help schema */

class novell_dmhelp_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes
		$this->attribute_schema = array(
			array("name"=>"DMAllowSystemLaunch",	"data_type"=>"yes_no",		"display_name"=>gettext("Allow System Launch")),
			array("name"=>"DMAllowSystemSend",	"data_type"=>"yes_no",		"display_name"=>gettext("Allow System Send")),
			array("name"=>"DMAllowUserLaunch",	"data_type"=>"yes_no",		"display_name"=>gettext("Allow User Launch")),
			array("name"=>"DMAllowUserSend",	"data_type"=>"yes_no",		"display_name"=>gettext("Allow User Send")),
			array("name"=>"DMContactName",		"data_type"=>"text",		"display_name"=>gettext("Contact Name")),
			array("name"=>"DMEMailAddress",		"data_type"=>"text",		"display_name"=>gettext("E-Mail Address")),
			array("name"=>"DMTelephoneNumber",	"data_type"=>"text",		"display_name"=>gettext("Telephone Number")),
			array("name"=>"DMTTDeliveryMethod",	"data_type"=>"text",		"display_name"=>gettext("Trouble Ticket Delivery Method")),	// enum
			array("name"=>"DMTTSubjectLines",	"data_type"=>"text",		"display_name"=>gettext("Trouble Ticket Subject Lines"))
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"HelpDeskPolicy",			"icon"=>"novell/helpdesk-policy.png",	"is_folder"=>false,"display_name"=>gettext("Help Desk Policy"),"parent_class"=>"Policy,UserPolicy")
			);

                parent::__construct($ldap_server);
        }
}
?>
