<?php
/** CORBA object schema (corba.schema)

    @see http://www.ietf.org/rfc/rfc2714.txt
*/

class corba_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"corbaIor",			"data_type"=>"text",		"display_name"=>gettext("CORBA Interoperable Object Reference")),
			array("name"=>"corbaRepositoryId",		"data_type"=>"text",		"display_name"=>gettext("CORBA Interface Repository ID"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"corbaContainer",			"icon"=>"corba-container.png",	"is_folder"=>true,"display_name"=>gettext("CORBA Container"),"parent_class"=>"corbaObject"),
			array("name"=>"corbaObject",			"icon"=>"corba-object-ref.png",	"class_type"=>"abstract"),
			array("name"=>"corbaObjectReference",		"icon"=>"corba-object.png",	"class_type"=>"auxiliary","display_name"=>gettext("CORBA Object Reference"),"parent_class"=>"corbaObject","required_attribs"=>"corbaIor","can_create"=>true)
			);

		// Display layouts

		$ldap_server->add_display_layout("corbaContainer",array(
			array("section_name"=>gettext("CORBA Container"),
				"attributes"=>array(
					array("cn",				gettext("Name"),				"corba-container.png")
					)
				)
			));

		$ldap_server->add_display_layout("corbaObjectReference",array(
			array("section_name"=>gettext("CORBA Object Reference"),
				"attributes"=>array(
					array("corbaIor",			gettext("Object Reference"),			"corba-object-ref.png"),
					array("corbaRepositoryId",		gettext("Repository ID"),			"generic24.png"),
                                        array("description",                    gettext("Description"),                         "description.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
