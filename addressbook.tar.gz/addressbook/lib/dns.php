<?php
/* ************************************************************************

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU Affero General Public License as published
   by the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Affero General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   ************************************************************************ */

/** Array of DNS record class names

    @see https://www.iana.org/assignments/dns-parameters/dns-parameters.xml
*/

$dns_record_class_name = array(
	1=>"IN",		// Internet
	2=>"CS",		// CSNET (obsolete)
	3=>"CH",		// CHAOS
	4=>"HS"			// Hesiod
	);

/** Array of DNS record type names

    @see https://www.iana.org/assignments/dns-parameters/dns-parameters.xml
*/

$dns_record_type_name = array(
	1=>"A",			// IPv4 Address						(RFC1035)
	2=>"NS",		// Name server						(RFC1035)
	3=>"MD",		// Mail Destination (obsolete; superceded by MX)	(RFC883)
	4=>"MF",		// Mail Forwarder (obsolete; superceded by MX)		(RFC883)
	5=>"CNAME",		// Canonical name for alias				(RFC1035)
	6=>"SOA",		// Start of authority					(RFC1035)
	7=>"MB",		// Mailbox domain name (experimental)			(RFC883)
	8=>"MG",		// Mail group member (experimental)			(RFC883)
	9=>"MR",		// Mail rename domain name (experimental)		(RFC883)
	10=>"NULL",		// Null (experimental)					(RFC883)
	11=>"WKS",		// Well-known service specification			(RFC883)
	12=>"PTR",		// Domain name pointer					(RFC1035)
	13=>"HINFO",		// Host information					(RFC883)
	14=>"MINFO",		// Mailbox or mail list information			(RFC1035)
	15=>"MX",		// Mail exchanger					(RFC1035)
	16=>"TXT",		// Text string						(RFC1035)
	17=>"RP",		// Responsible Person					(RFC1183)
	18=>"AFSDB",		// AFS cell database					(RFC1183)
	19=>"X25",		// X.25 PSDN Address					(RFC1183)
	20=>"ISDN",		// ISDN Address						(RFC1183)
	21=>"RT",		// Route Through					(RFC1183)
	22=>"NSAP",		// NSAP Address (obsolete)				(RFC1348)
	23=>"NSAP-PTR",		// NSAP to domain name pointer (obsolete)		(RFC1348)
	24=>"SIG",		// Signature (SIG/TKEY)					(RFC2535)
	25=>"KEY",		// Key record						(RFC2535)
	26=>"PX",		// Pointer to X.400/RFC822 mapping info			(RFC1664)
	27=>"GPOS",		// Geographical position				(RFC1712)
	28=>"AAAA",		// IPv6 address						(RFC3596)
	29=>"LOC",		// Location						(RFC1876)
	30=>"NXT",		// Next domain (obsolete)				(RFC2065)
	31=>"EID",		// Endpoint Identifier (obsolete)			(draft-ietf-nimrod-dns-01)
	32=>"NIMLOC",   	// Nimrod Locator (obsolete)				(draft-ietf-nimrod-dns-01)
	33=>"SRV",		// Service Locator					(RFC2782)
	34=>"ATMA",		// ATM Address
	35=>"NAPTR",		// Naming Authority Pointer				(RFC3403)
	36=>"KX",		// Key exchanger					(RFC2230)
	37=>"CERT",		// Certificate						(RFC4398)
	38=>"A6",		// IPv6 address (obsolete - use AAAA instead)		(RFC2874)
	39=>"DNAME",		// Domain Name Redirection				(RFC6672)
	40=>"SINK",		// Kitchen sink						(draft-eastlake-kitchen-sink-02)
	41=>"OPT",		// Option (pseudo-type)					(RFC6891)
	42=>"APL",		// Address prefix list (experimental)			(RFC3123)
	43=>"DS",		// Delegation signer					(RFC4034)
	44=>"SSHFP",		// SSH public key fingerprint				(RFC4255)
	45=>"IPSECKEY",		// IPsec key						(RFC4025)
	46=>"RRSIG",		// Resource Record Signature (DNSSEC)			(RFC4034)
	47=>"NSEC",		// Next secure record					(RFC4034)
	48=>"DNSKEY",		// DNS Key						(RFC4034)
	49=>"DHCID",		// RFC4701: DHCP Identifier				(RFC4701)
	50=>"NSEC3",		// RFC5155: Next secure record (v3)			(RFC5155)
	51=>"NSEC3PARAM",	// RFC5155: NSEC3 Paramaters				(RFC5155)
	52=>"TLSA",		// RFC6698: TLSA certificate association		(RFC6698)
	53=>"SMIMEA",		// RFC8162: S/MIME certificate association		(RFC8162)
	// 54 unassigned
	55=>"HIP",		// Host identity protocol				(RFC8005)
	56=>"NINFO",		// Namespace Info (zone status) (obsolete)		(draft-reid-dnsext-zs-01)
	57=>"RKEY",		// Resource record key (obsolete)			(draft-reid-dnsext-rkey-00)
	58=>"TALINK",		// Trust anchor link (obsolete)				(draft-wijngaards-dnsop-trust-history-02)
	59=>"CDS",		// Child copy of DS record				(RFC7344)
	60=>"CDNSKEY",		// Child copy of DNS key record				(RFC7344)
	61=>"OPENPGPKEY",	// OpenPGP public key record				(RFC7929)
	62=>"CSYNC",		// Child-To-Parent Synchronization			(RFC7477)
	63=>"ZONEMD",		// Zone Message Digest					(draft-wessels-dns-zone-digest-06)
	// 64-98 unassigned
	99=>"SPF",		// Sender policy framework				(RFC4408)
	100=>"UINFO",		// IANA reserved
	101=>"UID",		// IANA reserved
	102=>"GID",		// IANA reserved
	103=>"UNSPEC",		// IANA reserved
	104=>"NID",		// Node Identifier					(RFC6742)
	105=>"L32",		// 32-bit Locator					(RFC6742)
	106=>"L64",		// 64-bit Locator					(RFC6742)
	107=>"LP",		// Locator Pointer					(RFC6742)
	108=>"EUI48",		// 48-bit Extended Unique Identifier			(RFC7043)
	109=>"EUI64",		// 64-bit Extended Unique Identifier			(RFC7043)
	// 110-248 unassigned
	249=>"TKEY",		// Transaction key (TSIG)				(RFC2930)
	250=>"TSIG",		// Transaction signature				(RFC2845)
	251=>"IXFR",		// Incremental zone transfer query			(RFC1996)
	252=>"AXFR",		// Authoritative zone transfer query			(RFC1035)
	253=>"MAILB",		// Mail query B						(RFC883)
	254=>"MAILA",		// Mail query A						(RFC883)
	255=>"*",		// All cached records query				(RFC1035)
	256=>"URI",		// Uniform resource identifier				(RFC7553)
	257=>"CAA",		// Certification authority authorisation		(RFC6844)
	258=>"AVC",		// Application Visibility and Control			(Cisco)
	259=>"DOA",		// Digital Object Architecture				(draft-durand-doa-over-dns-03)
	260=>"AMTRELAY",	// Automatic Multicast Tunneling Relay			(draft-ietf-mboned-driad-amt-discovery-08)
	// 261-32767 unassigned
	32768=>"TA",		// DNSSEC Trust Authorities
	32769=>"DLV",		// DNSSEC Lookaside Validation				(RFC4431)
	// 32770 onwards unassigned
	);
?>
