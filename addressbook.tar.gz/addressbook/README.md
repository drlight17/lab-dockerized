# ldap-addressbook
LDAP addressbook based on sourceforge project

For KSC RAS
