<?php
/** Samba 3 Schema (samba.schema)

    Note: If using Samba 4 onwards, specify "ad" as the server type rather than using
    this schema.

    Samba 3 provides Windows NT-style file/print services. User, group and configuration
    details can be stored in an LDAP directory.

    Serveral attributes were named differently in early versions of the Samba schema.
    Where there is a direct equivalence to the current name, support for the old name is
    implemented using alias_names.
*/

class samba_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		/** The sambaLogonToChgPwd attribute indicates whether the user must log on to change their password. */

		$ldap_server->add_enum_data_type("logon_pwchange",
			array(
				array("value"=>"0","display_name"=>gettext("No")),
				array("value"=>"2","display_name"=>gettext("Yes"))
				)
			);

		/** The sambaForceLogoff attribute indicates whether to forcibly disconnect users outside their login hours. */

		$ldap_server->add_enum_data_type("logoff_ooh",
			array(
				array("value"=>"0","display_name"=>gettext("Yes")),
				array("value"=>"-1","display_name"=>gettext("No"))
				)
			);

		/** The sambaRefuseMachinePwdChange attribute indicates whether or not machine password changes should be allowed. */

                $ldap_server->add_enum_data_type("machine_pwchange",
                        array(
                                array("value"=>"0","display_name"=>gettext("Accepted")),
                                array("value"=>"1","display_name"=>gettext("Refused"))
                                ));

		/** The sambaTrustType attribute describes the trust relationship with an additional domain */

                $ldap_server->add_enum_data_type("samba_trusttype",
                        array(
                                array("value"=>"0","display_name"=>gettext("None")),
                                array("value"=>"1","display_name"=>gettext("Forest")),
                                array("value"=>"2","display_name"=>gettext("In-Forest")),
                                array("value"=>"3","display_name"=>gettext("External"))
                                )
                        );

		// Attributes

		$this->attribute_schema = array(
			array("name"=>"sambaAcctFlags",			"data_type"=>"text",		"display_name"=>gettext("Account Flags"),			"alias_names"=>"acctFlags"),
			array("name"=>"sambaAlgorithmicRidBase",	"data_type"=>"text",		"display_name"=>gettext("Base Value for RID Generation")),
			array("name"=>"sambaBadPasswordCount",		"data_type"=>"text",		"display_name"=>gettext("Number of Consecutive Login Failures")),
			array("name"=>"sambaBadPasswordTime",		"data_type"=>"text",		"display_name"=>gettext("Time of Last Login Failure")),
			array("name"=>"sambaBoolOption",		"data_type"=>"yes_no",		"display_name"=>gettext("Boolean Option")),
			array("name"=>"sambaClearTextPassword",		"data_type"=>"text",		"display_name"=>gettext("Clear Text Password")),
			array("name"=>"sambaDomainName",		"data_type"=>"text",		"display_name"=>gettext("Windows NT Domain Name"),		"alias_names"=>"domain"),
			array("name"=>"sambaFlatName",			"data_type"=>"text",		"display_name"=>gettext("NetBIOS Domain Name")),
			array("name"=>"sambaForceLogoff",		"data_type"=>"logoff_ooh",	"display_name"=>gettext("Disconnect Users Outside Login Hours")),
			array("name"=>"sambaGroupType",			"data_type"=>"text",		"display_name"=>gettext("Group Type")),
			array("name"=>"sambaHomeDrive",			"data_type"=>"text",		"display_name"=>gettext("Home Drive Letter"),			"alias_names"=>"homeDrive"),
			array("name"=>"sambaHomePath",			"data_type"=>"text",		"display_name"=>gettext("Home Drive UNC Path"),			"alias_names"=>"smbHome"),
			array("name"=>"sambaIntegerOption",		"data_type"=>"text",		"display_name"=>gettext("Integer Option")),
			array("name"=>"sambaKickoffTime",		"data_type"=>"text",		"display_name"=>gettext("Automatic Logoff After"),		"alias_names"=>"kickoffTime"),
			array("name"=>"sambaLMPassword",		"data_type"=>"text",		"display_name"=>gettext("LAN Manager Password Hash"),		"alias_names"=>"lmPassword"),
			array("name"=>"sambaLockoutDuration",		"data_type"=>"text",		"display_name"=>gettext("Account Lockout Duration")),
			array("name"=>"sambaLockoutObservationWindow",	"data_type"=>"text",		"display_name"=>gettext("Time After Lockout to Reset Bad Password Count")),
			array("name"=>"sambaLockoutThreshold",		"data_type"=>"text",		"display_name"=>gettext("Maximum Password Attempts Before Lockout")),
			array("name"=>"sambaLogoffTime",		"data_type"=>"text",		"display_name"=>gettext("Last Logoff Time"),			"alias_names"=>"logoffTime"),
			array("name"=>"sambaLogonHours",		"data_type"=>"text",		"display_name"=>gettext("Allowed Logon Hours")),
			array("name"=>"sambaLogonScript",		"data_type"=>"text",		"display_name"=>gettext("Logon Script UNC Path"),		"alias_names"=>"scriptPath"),
			array("name"=>"sambaLogonTime",			"data_type"=>"text",		"display_name"=>gettext("Last Logon Time"),			"alias_names"=>"logonTime"),
			array("name"=>"sambaLogonToChgPwd",		"data_type"=>"logon_pwchange",	"display_name"=>gettext("User Must Log On To Change Password")),
			array("name"=>"sambaMaxPwdAge",			"data_type"=>"text",		"display_name"=>gettext("Maximum Password Age")),
			array("name"=>"sambaMinPwdAge",			"data_type"=>"text",		"display_name"=>gettext("Minimum Password Age")),
			array("name"=>"sambaMinPwdLength",		"data_type"=>"text",		"display_name"=>gettext("Minimum Accepted Password Length")),
			array("name"=>"sambaMungedDial",		"data_type"=>"text",		"display_name"=>gettext("RAS/RDP User Parameters")),
			array("name"=>"sambaNextGroupRid",		"data_type"=>"text",		"display_name"=>gettext("Next Available Group RID")),
			array("name"=>"sambaNextRid",			"data_type"=>"text",		"display_name"=>gettext("Next Available RID (for Anything)")),
			array("name"=>"sambaNextUserRid",		"data_type"=>"text",		"display_name"=>gettext("Next Available User RID")),
			array("name"=>"sambaNTPassword",		"data_type"=>"text",		"display_name"=>gettext("NT Password Hash"),			"alias_names"=>"ntPassword"),
			array("name"=>"sambaOptionName",		"data_type"=>"text",		"display_name"=>gettext("Option Name")),
			array("name"=>"sambaPasswordHistory",		"data_type"=>"text_list",	"display_name"=>gettext("Password History")),
			array("name"=>"sambaPreviousClearTextPassword",	"data_type"=>"text",		"display_name"=>gettext("Previous Clear Text Password")),

			// Early versions of Samba stored a RID in the 'primaryGroupID'
			// attribute instead of a SID in 'sambaPrimaryGroupSID'
			array("name"=>"sambaPrimaryGroupSID",		"data_type"=>"text",		"display_name"=>gettext("Primary Group SID")),

			array("name"=>"sambaProfilePath",		"data_type"=>"text",		"display_name"=>gettext("User Profile UNC Path"),		"alias_names"=>"profilePath"),
			array("name"=>"sambaPwdCanChange",		"data_type"=>"text",		"display_name"=>gettext("Password Change Allowed After"),	"alias_names"=>"pwdCanChange"),
			array("name"=>"sambaPwdHistoryLength",		"data_type"=>"text",		"display_name"=>gettext("Password History Length")),
			array("name"=>"sambaPwdLastSet",		"data_type"=>"text",		"display_name"=>gettext("Last Password Change"),		"alias_names"=>"pwdLastSet"),
			array("name"=>"sambaPwdMustChange",		"data_type"=>"text",		"display_name"=>gettext("Password Change Required After"),	"alias_names"=>"pwdMustChange"),
			array("name"=>"sambaRefuseMachinePwdChange",	"data_type"=>"machine_pwchange","display_name"=>gettext("Allow Machine Password Changes")),
			array("name"=>"sambaSecurityIdentifier",	"data_type"=>"text",		"display_name"=>gettext("Trusted Domain SID")),
			array("name"=>"sambaShareName",			"data_type"=>"text",		"display_name"=>gettext("Share Name")),

			// Early versions of Samba stored a RID in the 'rid' attribute
			// instead of a SID in 'sambaSID'
			array("name"=>"sambaSID",			"data_type"=>"text",		"display_name"=>gettext("SID")),

			array("name"=>"sambaSIDList",			"data_type"=>"text_list",	"display_name"=>gettext("SID List")),
			array("name"=>"sambaStringListOption",		"data_type"=>"text_list",	"display_name"=>gettext("String List Option")),
			array("name"=>"sambaStringOption",		"data_type"=>"text",		"display_name"=>gettext("String Option")),
			array("name"=>"sambaSupportedEncryptionTypes",	"data_type"=>"text",		"display_name"=>gettext("Trust Supported Encryption Types")),
			array("name"=>"sambaTrustAttributes",		"data_type"=>"text",		"display_name"=>gettext("Trusted Domain Trust Attributes")),
			array("name"=>"sambaTrustAuthIncoming",		"data_type"=>"text",		"display_name"=>gettext("Trust Inbound Authentication Info")),
			array("name"=>"sambaTrustAuthOutgoing",		"data_type"=>"text",		"display_name"=>gettext("Trust Outbound Authentication Info")),
			array("name"=>"sambaTrustDirection",		"data_type"=>"text",		"display_name"=>gettext("Trust Direction")),
			array("name"=>"sambaTrustFlags",		"data_type"=>"samba_trustflags","display_name"=>gettext("Trust Password Flags")),
			array("name"=>"sambaTrustForestTrustInfo",	"data_type"=>"text",		"display_name"=>gettext("Trusted Domain Forest Trust Info")),
			array("name"=>"sambaTrustPartner",		"data_type"=>"text",		"display_name"=>gettext("Trusted Domain Name")),
			array("name"=>"sambaTrustPosixOffset",		"data_type"=>"text",		"display_name"=>gettext("Trust POSIX Offset")),
			array("name"=>"sambaTrustType",			"data_type"=>"samba_trusttype",	"display_name"=>gettext("Trust Type")),
			array("name"=>"sambaUserWorkstations",		"data_type"=>"text",		"display_name"=>gettext("Allowed Logon Workstations"),		"alias_names"=>"userWorkstations"),

			// Historcal attributes, retired during privilege rewrite

			array("name"=>"sambaPrivilegeList",		"data_type"=>"text",		"display_name"=>gettext("Privilege List")),
			array("name"=>"sambaPrivName",			"data_type"=>"text",		"display_name"=>gettext("Privilege Name"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"sambaConfig",			"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Samba Configuration Section")),
			array("name"=>"sambaConfigOption",		"icon"=>"generic24.png",	"is_folder"=>false,"display_name"=>gettext("Samba Configuration Option"),"rdn_attrib"=>"sambaOptionName"),
			array("name"=>"sambaDomain",			"icon"=>"domain24.png",		"is_folder"=>false,"display_name"=>gettext("Samba Domain"),"rdn_attrib"=>"sambaDomainName","required_attribs"=>"sambaSID"),
			array("name"=>"sambaGroupMapping",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Samba Group Mapping"),"required_attribs"=>"gidNumber,sambaGroupType,sambaSID"),
			array("name"=>"sambaIdmapEntry",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("SID to UNIX UID/GID Mapping"),"required_attribs"=>"sambaSID"),
			array("name"=>"sambaSamAccount",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Samba Account Details"),"required_attribs"=>"sambaSID,uid"),
			array("name"=>"sambaShare",			"icon"=>"generic24.png",	"is_folder"=>false,"display_name"=>gettext("Samba Share Configuration Section"),"rdn_attrib"=>"sambaShareName"),
			array("name"=>"sambaSidEntry",			"icon"=>"id.png",		"is_folder"=>false,"display_name"=>gettext("SID"),"rdn_attrib"=>"sambaSID"),
			array("name"=>"sambaTrustedDomain",		"icon"=>"domain24.png",		"is_folder"=>false,"display_name"=>gettext("Samba Trusted Domain")),
			array("name"=>"sambaTrustedDomainPassword",	"icon"=>"password.png",		"is_folder"=>false,"display_name"=>gettext("Samba Trusted Domain Password"),"contained_by"=>"sambaDomain","rdn_attrib"=>"sambaDomainName","required_attribs"=>"sambaClearTextPassword,sambaPwdLastSet,sambaSID","can_create"=>true),
			array("name"=>"sambaTrustPassword",		"icon"=>"password.png",		"is_folder"=>false,"display_name"=>gettext("Samba Trusted Domain Password (Legacy)"),"rdn_attrib"=>"sambaDomainName","required_attribs"=>"sambaNTPassword,sambaTrustFlags"),

			array("name"=>"sambaUnixIdPool",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Samba UNIX UID/GID Pool"),"required_attribs"=>"uidNumber,gidNumber"),

			// Historical predecessors of the sambaSamAccount object class:
			// smbPasswordEntry was replaced by sambaAccount, then by sambaSamAccount
			// (Note that structural and auxiliary versions of sambaAccount existed.)

			// array("name"=>"smbPasswordEntry",		"icon"=>"generic24.png",	"is_folder"=>false,"display_name"=>gettext("Samba Password Entry")),	// cf. smbpasswd file
        	        // array("name"=>"sambaAccount",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Samba Account Details")),
			// array("name"=>"sambaAccount",		"icon"=>"generic24.png",	"is_folder"=>false,"display_name"=>gettext("Samba Account")),

			// Historcal object class, retired during privilege rewrite

			// array("name"=>"sambaPrivilege",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Samba Privilege")),
			);

		// Display layouts

		$ldap_server->add_display_layout("sambaDomain",array(
			array("section_name"=>gettext("Samba Domain"),
				"attributes"=>array(
					array("sambaDomainName",		gettext("Domain Name"),			"domain24.png"),
					array("sambaSID",			gettext("SID"),				"id.png")
					)
				),
			array("section_name"=>gettext("Password Expiry Policy"),"new_row"=>true,
				"attributes"=>array(
					array("sambaMaxPwdAge",			gettext("Maximum Password Age (s)"),	"time.png"),
					)
				),
			array("section_name"=>gettext("Password Changing Policy"),"new_row"=>true,
				"attributes"=>array(
					array("sambaMinPwdAge",			gettext("Minimum Password Age (s)"),	"time.png"),
					array("sambaLogonToChgPwd",		gettext("User Must Log On To Change Password"),"generic24.png"),
					array("sambaMinPwdLength",		gettext("Minimum Accepted Password Length"),"generic24.png"),
					array("sambaPwdHistoryLength",		gettext("Number of Passwords to Store in History"),"generic24.png")
					)
				),
			array("section_name"=>gettext("Consecutive Login Failures Policy"),"new_row"=>true,
				"attributes"=>array(
					array("sambaLockoutThreshold",		gettext("Number of Consecutive Login Failures before Account is Locked"),"generic24.png"),
					array("sambaLockoutDuration",		gettext("Account Lock Time after Consecutive Login Failures (m)"),"time.png"),
					array("sambaLockoutObservationWindow",	gettext("Reset Time for Failed Logins Counter (m)"),"time.png"),
					)
				),
			array("section_name"=>gettext("RID Management"),"new_row"=>true,
				"attributes"=>array(
					array("sambaAlgorithmicRidBase",	gettext("Base Value for RID Generation"),"generic24.png"),
					array("sambaNextRid",			gettext("Next Available RID (for Anything)"),"generic24.png"),
					array("sambaNextGroupRid",		gettext("Next Available Group RID"),	"generic24.png"),
					array("sambaNextUserRid",		gettext("Next Available User RID"),	"generic24.png"),
					)
				),
			array("section_name"=>gettext("Other"),"new_row"=>true,
				"attributes"=>array(
					array("sambaRefuseMachinePwdChange",	gettext("Machine Password Changes"),	"generic24.png"),
					array("sambaForceLogoff",		gettext("Disconnect Users Outside Login Hours"),"generic24.png"),
					)
				),
                        array("section_name"=>gettext("Child Objects"),"new_row"=>true,
                                "attributes"=>array(
                                        array("__CHILD_OBJECTS__")
                                        )
                                )
			));

		$ldap_server->add_display_layout("sambaUnixIdPool",array(
			array("section_name"=>gettext("Samba UNIX ID Pool"),
				"attributes"=>array(
					array("uidNumber",			gettext("UID Pool"),			"id.png"),
					array("gidNumber",			gettext("GID Pool"),			"id.png")
					)
				)
			));

		$ldap_server->add_display_layout("sambaTrustedDomainPassword",array(
			array("section_name"=>gettext("Samba Trusted Domain"),
				"attributes"=>array(
					array("sambaDomainName",		gettext("Domain Name"),			"domain24.png"),
					array("sambaSID",			gettext("SID"),				"id.png")
					)
				),
			array("section_name"=>gettext("Trust Password"),
				"attributes"=>array(
					array("sambaClearTextPassword",		gettext("Current Password"),		"password.png"),
					array("sambaPreviousClearTextPassword",	gettext("Previous Password"),		"password.png"),
					array("sambaPwdLastSet",		gettext("Last Password Change"),	"time.png")
					)
				),
			));

		parent::__construct($ldap_server);
	}

	function populate_for_create_sambaDomain(&$ldap_server,&$entry)
	{
		$this->add_attrib_value($ldap_server,$entry,"sambaMinPwdAge","0");			// Allow immediate changes
		$this->add_attrib_value($ldap_server,$entry,"sambaMinPwdLength","5");
		$this->add_attrib_value($ldap_server,$entry,"sambaMaxPwdAge","-1");			// Disable password expiry
		$this->add_attrib_value($ldap_server,$entry,"sambaPwdHistoryLength","0");		// Off
		$this->add_attrib_value($ldap_server,$entry,"sambaLockoutThreshold","0");		// Off
		$this->add_attrib_value($ldap_server,$entry,"sambaLockoutDuration","-1");		// Forever
		$this->add_attrib_value($ldap_server,$entry,"sambaLockoutObservationWindow","30");
	}
}
?>
