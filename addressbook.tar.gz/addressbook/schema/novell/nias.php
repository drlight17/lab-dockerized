<?php
/** Novell Internet Access Server (NIAS) schema (partial) */

class novell_nias_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Object classes

		$this->object_schema = array(
			array("name"=>"iPXGWIPXIPGatewayServer",	"icon"=>"novell/ipx-ip-gateway.png",	"is_folder"=>false,"display_name"=>gettext("IPX/IP Gateway Server"),"parent_class"=>"Server","required_attribs"=>"iPXGWFileServerAssociation,iPXGWGatewayPort")
			);

		// Display layouts

		$ldap_server->add_display_layout("iPXGWIPXIPGatewayServer",array(
			array("section_name"=>gettext("IPX/IP Gateway Server"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),			"novell/ipx-ip-gateway.png"),
					array("iPXGWFileServerAssociation",	gettext("Associated File Server"),	"alias.png"),
					array("iPXGWGatewayPort",		gettext("Gateway Port"),		"generic24.png"),
					array("iPXGWAccessControlEnabled",	gettext("Access Control Enabled"),	"generic24.png"),
					array("iPXGWLicensedUsers",		gettext("Licenced Users"),		"generic24.png"),
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
