<?php
/** ZENworks Desktop Management Workstation schema */

class novell_dmwork_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"WMAbsolutePath",			"data_type"=>"dn",		"display_name"=>gettext("Absolute Path")),
			array("name"=>"WMDisableCreate",		"data_type"=>"yes_no",		"display_name"=>gettext("Disable Create")),
			array("name"=>"WMIncludeAllNetworkAddresses",	"data_type"=>"yes_no",		"display_name"=>gettext("Include All Network Addresses")),
			array("name"=>"WMInvalidNetworkAddress",	"data_type"=>"yes_no",		"display_name"=>gettext("Invalid Network Address")),
			array("name"=>"WMLastRegisteredTime",		"data_type"=>"date_time",	"display_name"=>gettext("Last Registered Time")),
			array("name"=>"WMNAMEComputer",			"data_type"=>"text",		"display_name"=>gettext("NAME Computer")),
			array("name"=>"WMNAMECPU",			"data_type"=>"text",		"display_name"=>gettext("NAME CPU")),
			array("name"=>"WMNAMEDNS",			"data_type"=>"text",		"display_name"=>gettext("NAME DNS")),
			array("name"=>"WMNAMEOS",			"data_type"=>"text",		"display_name"=>gettext("NAME OS")),
			array("name"=>"WMNAMEServer",			"data_type"=>"text",		"display_name"=>gettext("NAME Server")),
			array("name"=>"WMNAMEUser",			"data_type"=>"dn",		"display_name"=>gettext("NAME User")),
			array("name"=>"WMNetworkAddress",		"data_type"=>"text_list",	"display_name"=>gettext("Network Address")),
			array("name"=>"WMPreferredNetworkAddress",	"data_type"=>"text",		"display_name"=>gettext("Preferred Network Address")),
			array("name"=>"WMRegisteredWorkstation",	"data_type"=>"text_list",	"display_name"=>gettext("Registered Workstation")),
			array("name"=>"WMRelativePath",			"data_type"=>"text",		"display_name"=>gettext("Relative Path")),
			array("name"=>"WMRelativeTo",			"data_type"=>"text",		"display_name"=>gettext("Relative To")),
			array("name"=>"WMUserDefinedString",		"data_type"=>"text",		"display_name"=>gettext("User Defined String")),
			array("name"=>"WMUserHistory",			"data_type"=>"dn_list",		"display_name"=>gettext("User History")),
			array("name"=>"WMValidNetworkAddress",		"data_type"=>"text",		"display_name"=>gettext("Valid Network Address")),
			array("name"=>"WMWorkstation",			"data_type"=>"dn",		"display_name"=>gettext("Workstation")),
			array("name"=>"WMWorkstationGroup",		"data_type"=>"dn_list",		"display_name"=>gettext("Workstation Group")),
			array("name"=>"WMWorkstationNameString",	"data_type"=>"text",		"display_name"=>gettext("Workstation Name String")),
			array("name"=>"WMWorkstationPath",		"data_type"=>"text",		"display_name"=>gettext("Workstation Path"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"Workstation",			"icon"=>"computer.png",			"is_folder"=>false,"display_name"=>gettext("Workstation"),"contained_by"=>"organizationalUnit,Organization","parent_class"=>"Computer"),
			array("name"=>"WorkstationCreationPolicy",	"icon"=>"novell/ws-creation-policy.png","is_folder"=>false,"display_name"=>gettext("Workstation Creation Policy"),"parent_class"=>"Policy,UserPolicy"),
			array("name"=>"WorkstationGroup",		"icon"=>"novell/ws-group.png",		"is_folder"=>false,"display_name"=>gettext("Workstation Group"),"contained_by"=>"organizationalUnit,Organization","parent_class"=>"groupOfNames")
			);

                parent::__construct($ldap_server);
        }
}
?>
