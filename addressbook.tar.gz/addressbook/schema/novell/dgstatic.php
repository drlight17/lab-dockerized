<?php
/** Dyanmic Groups Static Member Support */

class novell_dgstatic_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		$this->attribute_schema = array(
			array("name"=>"staticMember","data_type"=>"dn_list","display_name"=>gettext("Static Group Member")),
			);

		parent::__construct($ldap_server);
	}
}
?>
