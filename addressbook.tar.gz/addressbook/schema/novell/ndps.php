<?php
/** Novell Distributed Print Services (NDPS) schema (partial) */

class novell_ndps_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Object classes
		$this->object_schema = array(
			array("name"=>"nDPSBroker",			"icon"=>"novell/ndps-broker.png",	"is_folder"=>false,"display_name"=>gettext("NDPS Broker"),"parent_class"=>"Server"),
			array("name"=>"nDPSManager",			"icon"=>"novell/ndps-manager.png",	"is_folder"=>false,"display_name"=>gettext("NDPS Manager")),
			array("name"=>"nDPSPrinter",			"icon"=>"novell/ndps-printer.png",	"is_folder"=>false,"display_name"=>gettext("NDPS Printer"),"parent_class"=>"device")
			);

                parent::__construct($ldap_server);
        }
}
?>
