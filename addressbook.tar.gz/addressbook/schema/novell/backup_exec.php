<?php
/** Backup Exec NDS Schema Extensions */

class novell_backup_exec_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes
		$this->attribute_schema = array(
			array("name"=>"bkupExecControlData",		"data_type"=>"download",	"display_name"=>gettext("Backup Exec Control Data"))
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"bkupExecJobQueue",		"icon"=>"novell/job-queue.png",		"is_folder"=>false,"display_name"=>gettext("Backup Exec Job Queue"),"parent_class"=>"Queue"),
			array("name"=>"bkupExecJobServer",		"icon"=>"novell/job-server.png",	"is_folder"=>false,"display_name"=>gettext("Backup Exec Job Server"),"parent_class"=>"inetOrgPerson")
			);

		// Display layouts

		$ldap_server->add_display_layout("bkupExecJobServer",array(
			array("section_name"=>gettext("Backup Exec Job Server"),
				"attributes"=>array(
					array("cn",				gettext("Login Name"),		"novell/job-server.png"),
					array("sn",				gettext("SN"),			"company.png"),
					array("publicKey",			gettext("Public Key"),		"key-material.png"),
					)
				)
			));

		$ldap_server->add_display_layout("bkupExecJobQueue",array(
			array("section_name"=>gettext("Backup Exec Job Queue"),
				"attributes"=>array(
					array("cn",				gettext("Queue Name"),		"novell/job-queue.png"),
					array("hostServer",			gettext("Host Server"),		"alias.png"),
					array("queueDirectory",			gettext("Queue Directory"),	"folder.png"),
					)
				),
			array("section_name"=>gettext("Backup Exec Administrators"),"new_row"=>true,
				"attributes"=>array(
					array("operator"),
					)
				)
			));

		// Force bkupExecJobServer objects to be named using "cn" in sortable lists.
		// (This overrides the default use of "sn", which may contain the vendor
		// name rather than the object name)
		$ldap_server->force_rdn_for_sortable_name("bkupExecJobServer");

		parent::__construct($ldap_server);
	}
}
?>
