<?php
/** Novell ZENworks Desktop Management Policy schema */

class novell_dmpolicy_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes
		$this->attribute_schema = array(
			array("name"=>"DMAssociation",		"data_type"=>"text",		"display_name"=>gettext("Association")),
			array("name"=>"DMPolicy",		"data_type"=>"text",		"display_name"=>gettext("Policy"))
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"Policy",				"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"PolicyType",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"ContainerPolicy",		"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"UserPolicy",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"WorkstationPolicy",		"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"PolicyPlatform",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"WIN31Policy",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"WIN95Policy",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"WINNTPolicy",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"PolicyAttribute",		"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"PluralPolicy",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"HiddenPolicy",			"icon"=>"generic24.png",		"class_type"=>"abstract"),
			array("name"=>"CumulativePolicy",		"icon"=>"generic24.png",		"class_type"=>"abstract"),
			);

                parent::__construct($ldap_server);
        }
}
?>
