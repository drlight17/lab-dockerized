<?php
/** GroupWise schema (gwschema.sch) */

class novell_gw_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes
		$this->attribute_schema = array(
			array("name"=>"nGWAccountID",			"data_type"=>"text",		"display_name"=>gettext("Account ID")),
			array("name"=>"nGWArchiveMaxSize",		"data_type"=>"text",		"display_name"=>gettext("Maximum Archive Size")),
			array("name"=>"nGWBlindCopyMember",		"data_type"=>"dn_list",		"display_name"=>gettext("BCC Member")),
			array("name"=>"nGWCarbonCopyMember",		"data_type"=>"dn_list",		"display_name"=>gettext("Carbon Copy Member")),
			array("name"=>"nGWDocumentAreaSize",		"data_type"=>"text",		"display_name"=>gettext("Document Area Size")),
			array("name"=>"nGWExternalNetID",		"data_type"=>"text",		"display_name"=>gettext("External Net ID")),
			array("name"=>"nGWFileID",			"data_type"=>"text",		"display_name"=>gettext("File ID")),
			array("name"=>"nGWGroupWiseID",			"data_type"=>"text",		"display_name"=>gettext("GroupWise ID")),
			array("name"=>"nGWLibraryDisplayName",		"data_type"=>"text",		"display_name"=>gettext("Library Display Name")),
			array("name"=>"nGWMailboxExpirationTime",	"data_type"=>"date_time",	"display_name"=>gettext("Mailbox Expiration Time")),
			array("name"=>"nGWObjectID",			"data_type"=>"text",		"display_name"=>gettext("Object ID")),
			array("name"=>"nGWOwner",			"data_type"=>"text",		"display_name"=>gettext("Owner")),
			array("name"=>"nGWPostOffice",			"data_type"=>"dn",		"display_name"=>gettext("GroupWise Post Office")),
			array("name"=>"nGWStartingVersionNumber",	"data_type"=>"text",		"display_name"=>gettext("Starting Version Number")),
			array("name"=>"nGWType",			"data_type"=>"text",		"display_name"=>gettext("Type")),
			array("name"=>"nGWVisibility",			"data_type"=>"text",		"display_name"=>gettext("Visible in GroupWise Address Book")),
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"groupWiseAgent",			"icon"=>"mail-transport.png",		"is_folder"=>false,"display_name"=>gettext("GroupWise Agent"),"required_attribs"=>"nGWType","contained_by"=>"groupWiseDomain,groupWisePostOffice","can_create"=>true),
			array("name"=>"groupWiseDistributionList",	"icon"=>"novell/gw-distrib-list.png",	"is_folder"=>false,"display_name"=>gettext("GroupWise Distribution List"),"contained_by"=>"organization,organizationalUnit","can_create"=>true),
			array("name"=>"groupWiseDomain",		"icon"=>"mail-domain.png",		"is_folder"=>true,"display_name"=>gettext("GroupWise Domain"),"required_attribs"=>"nGWLanguage,nGWLocation,nGWTimeZoneID,nGWType","can_contain"=>"groupWiseAgent,groupWiseGateway,ndaServiceProvider,ndaWebAccessApplication","contained_by"=>"organization,organizationalUnit","can_create"=>true),
			array("name"=>"groupWiseExternalEntity",	"icon"=>"novell/gw-external-entity.png","is_folder"=>false,"display_name"=>gettext("GroupWise External Entity"),"required_attribs"=>"nGWExternalNetID,nGWPostOffice","parent_class"=>"organizationalPerson","can_create"=>true),
			array("name"=>"groupWiseGateway",		"icon"=>"novell/gw-gateway.png",	"is_folder"=>false,"display_name"=>gettext("GroupWise Gateway"),"required_attribs"=>"nGWDomain,nGWLocation","contained_by"=>"groupWiseDomain","parent_class"=>"groupWiseAgent","can_create"=>true),
			array("name"=>"groupWiseLibrary",		"icon"=>"novell/gw-library.png",	"is_folder"=>false,"display_name"=>gettext("GroupWise Library"),"required_attribs"=>"nGWPostOffice","parent_class"=>"Resource","can_create"=>true),
			array("name"=>"groupWisePostOffice",		"icon"=>"mailbox-server.png",		"is_folder"=>true,"display_name"=>gettext("GroupWise Post Office"),"required_attribs"=>"nGWDomain,nGWLanguage,nGWLocation,nGWTimeZoneID","parent_class"=>"Server","can_create"=>true),
			array("name"=>"groupWiseResource",		"icon"=>"novell/gw-resource.png",	"is_folder"=>false,"display_name"=>gettext("GroupWise Resource"),"parent_class"=>"Resource","can_create"=>true),

			array("name"=>"ndaServiceProvider",		"icon"=>"novell/gw-service-provider.png","is_folder"=>false,"required_attribs"=>"ndaProviderType","contained_by"=>"groupWiseDomain,organization,organizationalUnit","can_create"=>true),
			array("name"=>"ndaWebAccessApplication",	"icon"=>"novell/gw-web-access.png",	"is_folder"=>false,"required_attribs"=>"ndaApplicationType","contained_by"=>"groupWiseDomain,organization,organizationalUnit","can_create"=>true)
			);

		// Display layouts
		$ldap_server->add_display_layout("groupWiseDistributionList",array(
			array("section_name"=>gettext("GroupWise Distribution List"),"new_row"=>true,
				"attributes"=>array(
					array("cn",				gettext("Name"),			"generic24.png"),
					array("description",			gettext("Description"),			"description.png"),
					array("nGWGroupWiseID",			gettext("GroupWise ID"),		"id.png"),
					array("nGWPostOffice",			gettext("Post Office"),			"generic24.png"),
					array("nGWVisibility",			gettext("Visibility"),			"generic24.png"),
					array("securityEquals",			gettext("Security Equals"),		"alias.png"),
					)
				),
			array("section_name"=>gettext("Members"),"new_row"=>true,
				"attributes"=>array(
					array("member",				gettext("To"),				"generic24.png"),
					array("nGWCarbonCopyMember",		gettext("CC"),				"generic24.png"),
					array("nGWBlindCopyMember",		gettext("BCC"),				"generic24.png"),
					)
				),
			));

		$ldap_server->add_display_layout("groupWiseResource",array(
			array("section_name"=>gettext("GroupWise Resource"),"new_row"=>true,
				"attributes"=>array(
					array("cn",				gettext("Name"),			"generic24.png"),
					array("nGWPostOffice",			gettext("Post Office"),			"generic24.png"),
					array("nGWOwner",			gettext("Owner"),			"generic24.png"),
					array("nGWGroupWiseID",			gettext("GroupWise ID"),		"id.png"),
					array("nGWFileID",			gettext("File ID"),			"id.png"),
					array("nGWVisibility",			gettext("Visibility"),			"generic24.png"),
					array("nGWType",			gettext("Type"),			"generic24.png"),
					array("securityEquals",			gettext("Security Equals"),		"alias.png"),
					)
				),
			));

		$ldap_server->add_display_layout("groupWiseLibrary",array(
			array("section_name"=>gettext("GroupWise Library"),"new_row"=>true,
				"attributes"=>array(
					array("cn",				gettext("Name"),			"generic24.png"),
					array("nGWPostOffice",			gettext("Post Office"),			"alias.png"),
					array("member",				gettext("Members"),			"generic24.png"),
					array("nGWGroupWiseID",			gettext("GroupWise ID"),		"id.png"),
					array("nGWFileID",			gettext("File ID"),			"id.png"),
					array("nGWStartingVersionNumber",	gettext("Starting Version Number"),	"generic24.png"),
					array("nGWArchiveMaxSize",		gettext("Maximum Archive Size"),	"generic24.png"),
					array("nGWDocumentAreaSize",		gettext("Document Area Size"),		"generic24.png"),
					array("nGWLibraryDisplayName",		gettext("Library Display Name"),	"generic24.png"),
					array("securityEquals",			gettext("Security Equals"),		"alias.png"),
					)
				),
			));

		$ldap_server->add_display_layout("groupWiseExternalEntity",array(
			array("section_name"=>gettext("Personal"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),			"contact24.png","allow_view"=>false),
					array("givenName",			gettext("First Name"),			"contact24.png","allow_view"=>false),
					array("initials",			gettext("Initials"),			"contact24.png","allow_view"=>false),
					array("sn",				gettext("Last Name"),			"contact24.png","allow_view"=>false),
					array("generationQualifier",		gettext("Generation Qualifier"),	"contact24.png","allow_view"=>false),
					array("fullName",			gettext("Full Name"),			"contact24.png","allow_view"=>false),
					array("mail",				gettext("E-mail"),			"mail.png"),
			//		array("pager",				gettext("Pager"),			"generic24.png"),
					array("mobile",				gettext("Mobile Phone"),		"cell-phone.png"),
					array("street:physicalDeliveryOfficeName:st:postalCode",gettext("Postal Address"),"address.png"),
					)
				),
			array("section_name"=>gettext("Business/Work"),"width"=>"50%",
				"attributes"=>array(
					array("company",			gettext("Company"),			"company.png"),
					array("telephoneNumber",		gettext("Office Phone"),		"landline-phone.png"),
					array("facsimileTelephoneNumber",	gettext("Office Fax"),			"fax.png"),
					array("title",				gettext("Job Title"),			"org-role.png"),
					array("ou",				gettext("Department"),			"org.png"),
					array("l",				gettext("Office Location"),		"office.png")
					)
				),
			array("section_name"=>gettext("GroupWise"),"new_row"=>true,
				"attributes"=>array(
					array("nGWPostOffice",			gettext("Post Office"),			"alias.png"),
					array("nGWExternalNetID",		gettext("External Net ID"),		"id.png"),
					array("nGWGroupWiseID",			gettext("GroupWise ID"),		"id.png"),
					array("nGWObjectID",			gettext("Object ID"),			"object.png"),
					array("nGWAccountID",			gettext("Account ID"),			"id.png"),
					array("nGWVisibility",			gettext("Visibility"),			"generic24.png"),
					array("nGWFileID",			gettext("File ID"),			"id.png"),
					array("nGWMailboxExpirationTime",	gettext("Expiration Date"),		"date-time.png"),
					)
				),
			array("section_name"=>gettext("Group Membership"),"new_row"=>true,"colspan"=>2,
				"attributes"=>array(
					array("groupMembership")
					)
				),
			array("section_name"=>gettext("Additional Notes"),"new_row"=>true,"colspan"=>2,
				"attributes"=>array(
					array("description")
					)
				),
			/*
			array("section_name"=>gettext("See Also"),"new_row"=>true,"colspan"=>2,
				"attributes"=>array(
					array("seeAlso")
					)
				)
			*/
			));

		parent::__construct($ldap_server);
	}
}
?>
