<?php
/** Novell OpenSSH Administration Schema */

class novell_sshd_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"sshadmn-ActiveConnections",	"data_type"=>"text",		"display_name"=>gettext("Number of Active Connections")),
			array("name"=>"sshadmn-AttemptedConnections",	"data_type"=>"text",		"display_name"=>gettext("Number of Attempted Connections")),
			array("name"=>"sshadmn-ConfigurationInfo",	"data_type"=>"text_area",	"display_name"=>gettext("OpenSSH Configuration Info")),
			array("name"=>"sshadmn-FailedConnections",	"data_type"=>"text",		"display_name"=>gettext("Number of Failed Connections")),
			array("name"=>"sshadmn-ServerConfLastModified",	"data_type"=>"text",		"display_name"=>gettext("Last Configuration Update Time")),
			array("name"=>"sshadmn-ServerLastBackup",	"data_type"=>"text",		"display_name"=>gettext("Most Recent Configuration Backup File")),
			array("name"=>"sshadmn-ServerName",		"data_type"=>"text",		"display_name"=>gettext("OpenSSH Server Name")),
			array("name"=>"sshadmn-ServerPlatform",		"data_type"=>"text",		"display_name"=>gettext("OpenSSH Server Platform")),
			array("name"=>"sshadmn-ServerRestartDelay",	"data_type"=>"text",		"display_name"=>gettext("Configuration Change Polling Interval")),
			array("name"=>"sshadmn-ServerRestoreVersion",	"data_type"=>"text",		"display_name"=>gettext("Previous Configuration Backup File")),
			array("name"=>"sshadmn-ServerStartup",		"data_type"=>"text",		"display_name"=>gettext("Start/Restart Flag")),
			array("name"=>"sshadmn-ServerStartupError",	"data_type"=>"text",		"display_name"=>gettext("Startup Error Information")),
			array("name"=>"sshadmn-ServerStatus",		"data_type"=>"text",		"display_name"=>gettext("Last Startup Successful")),
			array("name"=>"sshadmn-SuccessfulConnections",	"data_type"=>"text",		"display_name"=>gettext("Number of Successful Connections")),
			array("name"=>"sshadmn-TypeName",		"data_type"=>"text",		"display_name"=>gettext("Type Name"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"sshadmnConfiguration",	"icon"=>"novell/sshd-server.png",	"class_type"=>"auxiliary"),
			array("name"=>"sshadmnServer",		"icon"=>"novell/sshd-server.png",	"is_folder"=>false,"required_attribs"=>"sshadmn-TypeName")
			);

		// Display layouts

		$ldap_server->add_display_layout("sshadmnServer",array(
			array("section_name"=>gettext("OpenSSH Server"),
				"attributes"=>array(
					array("cn",				gettext("Object Name"),		"novell/sshd-server.png"),
					array("sshadmn-ServerName",		gettext("Server Name"),		"generic24.png"),
					array("sshadmn-ServerStatus",		gettext("Server Status"),	"generic24.png"),
					array("sshadmn-ServerStartup",		gettext("Server Startup"),	"generic24.png")
					)
				),
			array("section_name"=>gettext("Configuration Info"),"new_row"=>true,
				"attributes"=>array(
					array("sshadmn-ServerConfLastModified",	gettext("Last Modified"),	"date-time.png"),
					array("sshadmn-TypeName",		gettext("Type Name"),		"object.png")
					)
				),
			array("section_name"=>gettext("Child Objects"),"new_row"=>true,
				"attributes"=>array(
					array("__CHILD_OBJECTS__")
					)
				)
			));

		// Auxiliary class display layouts

		$ldap_server->add_display_layout("sshadmnConfiguration",array(
			array("section_name"=>gettext("OpenSSH Server Configuration Settings"),"new_row"=>true,
				"attributes"=>array(
					array("sshadmn-ConfigurationInfo")
					)
				)
			));

		parent::__construct($ldap_server);
	}

        /** Assign default values for sshadmnServer attributes */

        function populate_for_create_sshadmnServer(&$ldap_server,&$entry)
        {
                $this->add_attrib_value($ldap_server,$entry,"sshadmn-TypeName","sshadmnServer");
        }
}
?>
