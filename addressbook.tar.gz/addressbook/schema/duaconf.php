<?php
/** Directory user agent (DUA) configuration schema (duaconf.schema)

    @see http://www.ietf.org/rfc/rfc4876.txt
*/

class duaconf_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"attributeMap",			"data_type"=>"text_list",	"display_name"=>gettext("Attribute Mapping")),
			array("name"=>"authenticationMethod",		"data_type"=>"text",		"display_name"=>gettext("Authentication Methods")),
			array("name"=>"bindTimeLimit",			"data_type"=>"text",		"display_name"=>gettext("Bind Time Limit")),
			array("name"=>"credentialLevel",		"data_type"=>"text",		"display_name"=>gettext("Credential Levels")),
			array("name"=>"defaultSearchBase",		"data_type"=>"dn",		"display_name"=>gettext("Default Search Base DN")),
			array("name"=>"defaultSearchScope",		"data_type"=>"search_scope",	"display_name"=>gettext("Default Search Scope")),
			array("name"=>"defaultServerList",		"data_type"=>"text",		"display_name"=>gettext("Default Servers")),
			array("name"=>"dereferenceAliases",		"data_type"=>"yes_no",		"display_name"=>gettext("Dereference Aliases")),
			array("name"=>"followReferrals",		"data_type"=>"yes_no",		"display_name"=>gettext("Follow Referrals")),
			array("name"=>"objectclassMap",			"data_type"=>"text_list",	"display_name"=>gettext("Object Class Mapping")),
			array("name"=>"preferredServerList",		"data_type"=>"text",		"display_name"=>gettext("Preferred Servers")),
			array("name"=>"profileTTL",			"data_type"=>"text",		"display_name"=>gettext("Configuration Profile TTL")),
			array("name"=>"searchTimeLimit",		"data_type"=>"text",		"display_name"=>gettext("Search Time Limit")),
			array("name"=>"serviceAuthenticationMethod",	"data_type"=>"text",		"display_name"=>gettext("Service-Specific Authentication Methods")),
			array("name"=>"serviceCredentialLevel",		"data_type"=>"text",		"display_name"=>gettext("Service-Specific Credential Levels")),
			array("name"=>"serviceSearchDescriptor",	"data_type"=>"text_list",	"display_name"=>gettext("Service-Specific Search Descriptors"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"DUAConfigProfile",		"icon"=>"ldap-client.png",	"is_folder"=>false,"display_name"=>gettext("Directory User Agent"))
			);

		// Display layouts

                $ldap_server->add_display_layout("DUAConfigProfile",array(
                        array("section_name"=>gettext("Directory User Agent Configuration Profile"),
                                "attributes"=>array(
                                        array("cn",				gettext("Profile Name"),	"ldap-client.png"),
                                        array("profileTTL",			gettext("Profile TTL (s)"),	"time.png"),
                                        array("defaultServerList",		gettext("Default Servers"),	"ldap-server.png"),
                                        array("preferredServerList",		gettext("Preferred Servers"),	"ldap-server.png"),
                                        array("bindTimeLimit",			gettext("Bind Time Limit (s)"),	"time.png")
                                        )
                                ),
                        array("section_name"=>gettext("Default Search Settings"),"new_row"=>true,
                                "attributes"=>array(
                                        array("defaultSearchBase",		gettext("Base DN"),		"generic24.png"),
                                        array("defaultSearchScope",		gettext("Scope"),		"generic24.png"),
                                        array("dereferenceAliases",		gettext("Dereference Aliases"),	"generic24.png"),
                                        array("followReferrals",		gettext("Follow Referrals"),	"server-alias.png"),
                                        array("searchTimeLimit",		gettext("Time Limit (s)"),	"time.png")
                                        )
                                ),
                        array("section_name"=>gettext("Default Service Settings"),"new_row"=>true,
                                "attributes"=>array(
                                        array("authenticationMethod",		gettext("Authentication Methods"),"password.png"),
                                        array("credentialLevel",		gettext("Credential Levels"),	"generic24.png")
                                        )
                                ),
                        array("section_name"=>gettext("Service-Specific Settings"),"new_row"=>true,
                                "attributes"=>array(
                                        array("serviceAuthenticationMethod",	gettext("Authentication Methods"),"password.png"),
                                        array("serviceCredentialLevel",		gettext("Credential Levels"),	"generic24.png"),
                                        array("serviceSearchDescriptor",	gettext("Search Descriptors"),	"generic24.png")
                                        )
                                ),
                        array("section_name"=>gettext("Attribute Mappings"),"new_row"=>true,
                                "attributes"=>array(
                                        array("attributeMap")
                                        )
                                ),
                        array("section_name"=>gettext("Object Class Mappings"),"new_row"=>true,
                                "attributes"=>array(
                                        array("objectclassMap")
                                        )
                                )
                        ));

		parent::__construct($ldap_server);
	}
}
?>
