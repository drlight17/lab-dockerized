<?php
/** Universal Description, Discovery, and Integration (UDDI) schema (uddischema.sch)

    @see https://tools.ietf.org/html/rfc4403
*/

class uddi_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"uddiAccessPoint",		"data_type"=>"text"),
			array("name"=>"uddiAddressLine",		"data_type"=>"text_list"),
			array("name"=>"uddiAuthorizedName",		"data_type"=>"dn"),
			array("name"=>"uddiBindingKey",			"data_type"=>"text"),
			array("name"=>"uddiBusinessKey",		"data_type"=>"text"),
			array("name"=>"uddiCategoryBag",		"data_type"=>"text_list"),
			array("name"=>"uddiDescription",		"data_type"=>"text_list"),
			array("name"=>"uddiDiscoveryURLs",		"data_type"=>"text_list"),
			array("name"=>"uddiEMail",			"data_type"=>"text_list"),
			array("name"=>"uddiFromKey",			"data_type"=>"text"),
			array("name"=>"uddiHostingRedirector",		"data_type"=>"text"),
			array("name"=>"uddiIdentifierBag",		"data_type"=>"text_list"),
			array("name"=>"uddiInstanceDescription",	"data_type"=>"text_list"),
			array("name"=>"uddiInstanceParms",		"data_type"=>"text"),
			array("name"=>"uddiIsHidden",			"data_type"=>"yes_no"),
			array("name"=>"uddiIsProjection",		"data_type"=>"yes_no"),
			array("name"=>"uddiKeyedReference",		"data_type"=>"text_list"),
			array("name"=>"uddiLang",			"data_type"=>"text"),	// not present in edir
			array("name"=>"uddiName",			"data_type"=>"text_list"),
			array("name"=>"uddiOperator",			"data_type"=>"text"),
			array("name"=>"uddiOverviewDescription",	"data_type"=>"text_list"),
			array("name"=>"uddiOverviewURL",		"data_type"=>"text"),
			array("name"=>"uddiPersonName",			"data_type"=>"text"),
			array("name"=>"uddiPhone",			"data_type"=>"text_list"),
			array("name"=>"uddiServiceKey",			"data_type"=>"text"),
			array("name"=>"uddiSortCode",			"data_type"=>"text"),
			array("name"=>"uddiTModelKey",			"data_type"=>"text"),
			array("name"=>"uddiToKey",			"data_type"=>"text"),
			array("name"=>"uddiUseType",			"data_type"=>"text"),
			array("name"=>"uddiUUID",			"data_type"=>"text"),

			// Novell proprietary classes (not present in RFC4403)

			array("name"=>"uddiAllowAuthInqNonSecure",	"data_type"=>"yes_no"),
			array("name"=>"uddiBaseContext",		"data_type"=>"dn"),
			array("name"=>"uddiCreateDiscoveryDoc",		"data_type"=>"yes_no"),
			array("name"=>"uddiDefaultLanguage",		"data_type"=>"text"),
			array("name"=>"uddiDiscoveryDocPath",		"data_type"=>"text"),
			array("name"=>"uddiDiscoveryDocURL",		"data_type"=>"text"),
			array("name"=>"uddiEnableAudit",		"data_type"=>"yes_no"),
			array("name"=>"uddiEnableLogging",		"data_type"=>"yes_no"),
			array("name"=>"uddiEnableSNMP",			"data_type"=>"yes_no"),
			array("name"=>"uddiHostServer",			"data_type"=>"dn"),
			array("name"=>"uddiIdleTimeout",		"data_type"=>"text"),
			array("name"=>"uddiInquiryURL",			"data_type"=>"text"),
			array("name"=>"uddiLogCategory",		"data_type"=>"text"),
			array("name"=>"uddiLogFileSize",		"data_type"=>"text"),
			array("name"=>"uddiLogLevel",			"data_type"=>"text"),
			array("name"=>"uddiMaxAuthAttempts",		"data_type"=>"text"),
			array("name"=>"uddiMaxBackendConnections",	"data_type"=>"text"),
			array("name"=>"uddiMaxBindingTemplates",	"data_type"=>"text"),
			array("name"=>"uddiMaxBusinessEntities",	"data_type"=>"text"),
			array("name"=>"uddiMaxBusinessServices",	"data_type"=>"text"),
			array("name"=>"uddiMaxNames",			"data_type"=>"text"),
			array("name"=>"uddiMaxPublisherAssertions",	"data_type"=>"text"),
			array("name"=>"uddiMaxSearchResults",		"data_type"=>"text"),
			array("name"=>"uddiMaxSoapMsgSize",		"data_type"=>"text"),
			array("name"=>"uddiMaxTModels",			"data_type"=>"text"),
			array("name"=>"uddiOperatorsName",		"data_type"=>"text"),
			array("name"=>"uddiPublishURL",			"data_type"=>"text"),
			array("name"=>"uddiReAuthPeriod",		"data_type"=>"text"),
			array("name"=>"uddiReconfigInterval",		"data_type"=>"text"),
			array("name"=>"uddiServerVersion",		"data_type"=>"text"),
			array("name"=>"uddiSessionTimeLimit",		"data_type"=>"text"),
			array("name"=>"uddiUserContext",		"data_type"=>"dn_list"),

			// UDDIv3-specific classes (not supported in eDirectory implementation)

			array("name"=>"uddiv3BindingKey",		"data_type"=>"text"),
			array("name"=>"uddiv3BriefResponse",		"data_type"=>"yes_no"),
			array("name"=>"uddiv3BusinessKey",		"data_type"=>"text"),
			array("name"=>"uddiv3DigitalSignature",		"data_type"=>"text"),
			array("name"=>"uddiv3ExpiresAfter",		"data_type"=>"date_time"),
			array("name"=>"uddiv3EntityCreationTime",	"data_type"=>"date_time"),
			array("name"=>"uddiv3EntityDeletionTime",	"data_type"=>"date_time"),
			array("name"=>"uddiv3EntityKey",		"data_type"=>"text"),
			array("name"=>"uddiv3EntityModificationTime",	"data_type"=>"date_time"),
			array("name"=>"uddiv3MaxEntities",		"data_type"=>"text"),
			array("name"=>"uddiv3NodeId",			"data_type"=>"text"),
			array("name"=>"uddiv3NotificationInterval",	"data_type"=>"text"),
			array("name"=>"uddiv3ServiceKey",		"data_type"=>"text"),
			array("name"=>"uddiv3SubscriptionFilter",	"data_type"=>"text"),
			array("name"=>"uddiv3SubscriptionKey",		"data_type"=>"text"),
			array("name"=>"uddiv3TModelKey",		"data_type"=>"text")
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"uddiAddress",			"icon"=>"generic24.png",	"is_folder"=>false,"rdn_attrib"=>"uddiUUID","contained_by"=>"uddiContact"),
			array("name"=>"uddiBindingTemplate",		"icon"=>"generic24.png",	"is_folder"=>true,"rdn_attrib"=>"uddiBindingKey","contained_by"=>"uddiBusinessService"),
			array("name"=>"uddiBusinessEntity",		"icon"=>"generic24.png",	"is_folder"=>true,"rdn_attrib"=>"uddiBusinessKey","contained_by"=>"country,domain,locality,organization,organizationalUnit"),
			array("name"=>"uddiBusinessService",		"icon"=>"generic24.png",	"is_folder"=>true,"rdn_attrib"=>"uddiServiceKey","contained_by"=>"uddiBusinessEntity"),
			array("name"=>"uddiContact",			"icon"=>"generic24.png",	"is_folder"=>true,"rdn_attrib"=>"uddiUUID","required_attribs"=>"uddiPersonName","contained_by"=>"uddiBusinessEntity"),
			array("name"=>"uddiPublisherAssertion",		"icon"=>"generic24.png",	"is_folder"=>false,"rdn_attrib"=>"uddiUUID","required_attribs"=>"uuidFromKey,uuidToKey,uuidKeyedReference","contained_by"=>"country,domain,locality,organization,organizationalUnit"),
			array("name"=>"uddiTModel",			"icon"=>"generic24.png",	"is_folder"=>false,"rdn_attrib"=>"uddiTModelKey","required_attribs"=>"uddiName","contained_by"=>"country,domain,locality,organization,organizationalUnit"),
			array("name"=>"uddiTModelInstanceInfo",		"icon"=>"generic24.png",	"is_folder"=>false,"rdn_attrib"=>"uddiTModelKey","contained_by"=>"uddiBindingTemplate"),

			// Novell proprietary classes (not present in RFC4403)
			array("name"=>"uddiRegistryConfig",		"icon"=>"generic24.png",	"class_type"=>"auxiliary","required_attribs"=>"uddiOperatorsName,uddiBaseContext"),
			array("name"=>"uddiServer",			"icon"=>"generic24.png",	"is_folder"=>false,"parent_class"=>"ndsLoginProperties","required_attribs"=>"uddiOperatorsName,uddiServerVersion,uddiUserContext","contained_by"=>"country,domain,locality,organization,organizationalUnit"),

			// UDDIv3-specific classes (not supported in eDirectory implementation)
			array("name"=>"uddiv3EntityObituary",		"icon"=>"generic24.png",	"is_folder"=>false,"rdn_attrib"=>"uddiUUID","required_attribs"=>"uddiv3EntityKey"),
			array("name"=>"uddiv3Subscription",		"icon"=>"generic24.png",	"is_folder"=>false,"rdn_attrib"=>"uddiUUID","required_attribs"=>"uddiv3SubscriptionFilter")
			);

		// Apply eDirectory-specific implementation details

		if($ldap_server->server_type == "edir")
		{
			// Apply non-standard schema implementation (relative to RFC4403)

			$ldap_server->modify_object_class("uddiBusinessEntity","rdn_attrib","uddiBusinessKey,uddiName");
			$ldap_server->modify_object_class("uddiBusinessService","required_attribs","uddiName");

			// Display columns for default object hierarchy

			$ldap_server->set_display_columns("ou=tmodels,ou=data,o=uddi",array(
				array("caption"=>gettext("Object Name"),	"attrib"=>"sortableName",			"link_type"=>"object"),
				array("caption"=>gettext("Display Name"),	"attrib"=>"uddiName",				"link_type"=>"none"),
				array("caption"=>gettext("Description"),	"attrib"=>"uddiDescription",			"link_type"=>"none")
				));

			$ldap_server->set_display_columns("ou=server,o=uddi",array(
				array("caption"=>gettext("Name"),		"attrib"=>"sortableName",			"link_type"=>"object"),
				array("caption"=>gettext("Inquiry URL"),	"attrib"=>"uddiInquiryURL",			"link_type"=>"none"),
				array("caption"=>gettext("Publish URL"),	"attrib"=>"uddiPublishURL",			"link_type"=>"none")
				));
		}

                parent::__construct($ldap_server);
        }
}
?>
