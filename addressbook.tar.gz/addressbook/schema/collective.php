<?php
/** Collective attribute schema (collective.schema)

    @see http://www.ietf.org/rfc/rfc3671.txt
*/

class collective_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"c-FacsimileTelephoneNumber",	"data_type"=>"text",		"display_name"=>gettext("Fax Number (Collective)")),
			array("name"=>"c-InternationalISDNNumber",	"data_type"=>"text",		"display_name"=>gettext("ISDN Number (Collective)")),
			array("name"=>"c-l",				"data_type"=>"text",		"display_name"=>gettext("Locality (e.g. Town/City) (Collective)")),
			array("name"=>"c-o",				"data_type"=>"text",		"display_name"=>gettext("Organization Name (Collective)")),
			array("name"=>"c-ou",				"data_type"=>"text",		"display_name"=>gettext("Organizational Unit Name (Collective)")),
			array("name"=>"c-PostalAddress",		"data_type"=>"text_area",	"display_name"=>gettext("Postal Address (Collective)")),
			array("name"=>"c-PostalCode",			"data_type"=>"postcode",	"display_name"=>gettext("Postal Code (Collective)")),
			array("name"=>"c-PostOfficeBox",		"data_type"=>"text",		"display_name"=>gettext("Post Office Box (Collective)")),
			array("name"=>"c-PhysicalDeliveryOfficeName",	"data_type"=>"text",		"display_name"=>gettext("Office (Collective)")),
			array("name"=>"c-st",				"data_type"=>"text",		"display_name"=>gettext("State (or Province/County) (Collective)")),
			array("name"=>"c-street",			"data_type"=>"text_area",	"display_name"=>gettext("Street Address (Collective)")),
			array("name"=>"c-TelephoneNumber",		"data_type"=>"phone_number",	"display_name"=>gettext("Telephone Number (Collective)")),
			array("name"=>"c-TelexNumber",			"data_type"=>"text",		"display_name"=>gettext("Telex Number (Collective)")),

			// Operational attributes

			array("name"=>"collectiveAttributeSubentries",	"data_type"=>"dn_list",		"display_name"=>gettext("Collective Attribute Subentries")),
			array("name"=>"collectiveExclusions",		"data_type"=>"oid_list",	"display_name"=>gettext("Excluded Collective Attributes"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"collectiveAttributeSubentry",	"icon"=>"generic24.png",	"class_type"=>"auxiliary","display_name"=>gettext("Collective Attributes"))
			);

                // Auxiliary class display layouts

                $ldap_server->add_display_layout("collectiveAttributeSubentry",array(
                        array("section_name"=>gettext("Collective Attributes"),
                                "attributes"=>array(
					array("c-o",				gettext("Company"),			"company.png"),
					array("c-ou",				gettext("Department"),			"org.png"),
					array("c-PhysicalDeliveryOfficeName",	gettext("Office"),			"office.png"),
					array("c-TelephoneNumber",		gettext("Office Phone"),		"landline-phone.png"),
					array("c-FacsimileTelephoneNumber",	gettext("Office Fax"),			"fax.png"),
					// array("c-InternationalISDNNumber",	gettext("ISDN"),			"landline-phone.png"),
					// array("c-TelexNumber",		gettext("Telex Number"),		"generic24.png"),

					// Single-attribute (unstructured) version of postal address
					//array("c-PostalAddress",		gettext("Postal Address"),		"address.png"),

					// Multi-attribute (structured) version of postal address
					array("c-PostOfficeBox:c-street:c-l:c-st:c-PostalCode",gettext("Postal Address"),"address.png")
					)
                                )
                        ));

		parent::__construct($ldap_server);
	}
}
?>
