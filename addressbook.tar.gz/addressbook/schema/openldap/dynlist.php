<?php
/** OpenLDAP Configuration (OLC) Schema for Dynamic Lists Overlay */

class openldap_dynlist_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		$this->attribute_schema = array(
			array("name"=>"olcDlAttrSet",			"data_type"=>"text_list",	"display_name"=>gettext("Member/Member URL Attribute Pair"))
			);

		// Object classes
		$this->object_schema = array(
			array("name"=>"olcDynamicList",			"icon"=>"openldap/overlay.png",		"is_folder"=>false,"rdn_attrib"=>"olcOverlay","display_name"=>gettext("Dynamic Lists Overlay"),"can_create"=>true,"parent_class"=>"olcOverlayConfig")
			);

		// Display layouts
		$ldap_server->add_display_layout("olcDynamicList",array(
			array("section_name"=>gettext("Dynamic Lists Overlay Settings"),"new_row"=>true,
				"attributes"=>array(
					array("olcOverlay",			gettext("Overlay Object Name"),				"openldap/overlay.png"),
					array("olcDlAttrSet",			gettext("Dynamic List Attributes"),			"dyngroup.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}

	function populate_for_create_olcDynamicList(&$ldap_server,&$entry)
	{
		$ldap_server->assign_ordered_sequence_rdn($entry,"olcOverlayConfig","dynlist");
		$this->add_attrib_value($ldap_server,$entry,"olcDlAttrSet","{0}groupOfURLs memberURL member");

		// Handle olcDlAttrSet as a single-valued text attribute during object creation
		$ldap_server->modify_attribute_class("olcDlAttrSet","data_type","text");
	}

	function before_create_olcDynamicList(&$ldap_server,&$entry)
	{
		$ldap_server->ensure_openldap_module_loaded("dynlist");
	}
}
?>
