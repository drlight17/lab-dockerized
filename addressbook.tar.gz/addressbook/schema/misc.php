<?php
/** Miscellaneous schema definitions shipped with OpenLDAP (misc.schema)

    This file contains schema definitions drawn from several different sources,
    generally relating to mail routing. The version of misc.schema shipped with
    OpenLDAP 2.4 defines:

      - The inetLocalMailRecipient class and its attributes, developed by
	the LDAP Schema for E-mail Routing (LASER) working group. It is often
	used when implementing LDAP routing with sendmail.

      - The nisMailAlias class, which is used in certain Netscape LDAP
	products (amongst others). Its rfc822MailMember attribute is described
        by the IETF draft LDAP Schema for Internet Mail.

    @see https://tools.ietf.org/html/draft-lachman-laser-ldap-mail-routing-02
    @see https://tools.ietf.org/html/draft-srivastava-ldap-mail-00

    The data type of mailLocalAddress, mailRoutingAddress and rfc822MailMember
    can be changed to text_list to support many-to-many mappings between aliases
    and forwarding destinations.
*/

class misc_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"mailHost",			"data_type"=>"text",		"display_name"=>gettext("SMTP/MTA Host Name")),
			array("name"=>"mailLocalAddress",		"data_type"=>"text",		"display_name"=>gettext("Local E-mail Address")),
			array("name"=>"mailRoutingAddress",		"data_type"=>"text",		"display_name"=>gettext("Routing Destination Address")),
			array("name"=>"rfc822MailMember",		"data_type"=>"text",		"display_name"=>gettext("Destination Mailbox"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"inetLocalMailRecipient",		"icon"=>"mail-recipient.png",		"class_type"=>"auxiliary","display_name"=>gettext("Local Mail Recipient"),"can_create"=>true),
			array("name"=>"nisMailAlias",			"icon"=>"generic24.png",		"is_folder"=>false,"display_name"=>gettext("NIS Mail Alias"))
			);

		// Display layouts

		$ldap_server->add_display_layout("nisMailAlias",array(
			array("section_name"=>gettext("NIS Mail Alias"),
				"attributes"=>array(
					array("cn",			gettext("Incoming E-Mail Address"),		"generic24.png"),
					array("rfc822MailMember",	gettext("Destination Mailbox"),			"mailbox-server.png")
					)
				)
			));

		// Auxiliary class display layouts

		$ldap_server->add_display_layout("inetLocalMailRecipient",array(
			array("section_name"=>gettext("Local Mail Recipient"),
				"attributes"=>array(
					array("mailLocalAddress",	gettext("Local E-mail Addresses"),		"mail.png"),
					array("mailHost",		gettext("Receiving SMTP/MTA Host Name"),	"server.png"),
					array("mailRoutingAddress",	gettext("Destination E-mail Address"),		"mailbox-server.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
