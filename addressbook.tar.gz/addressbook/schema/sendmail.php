<?php
/** Sendmail MTA configuration schema (sendmail.schema)

    This file contains schema definitions for storing Sendmail aliases, maps,
    and classes as LDAP objects:

    @see https://www.sendmail.org/~ca/email/doc8.12/cf/m4/ldap.html

    This schema can be used in conjunction with the inetLocalMailRecipient
    class (available in the "misc" schema), which can be used to control
    routing between Sendmail servers within an organisation.
*/

class sendmail_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		/** Custom enum data type for sendmailMTAClassName attribute */

                $ldap_server->add_enum_data_type("sendmail_class",
                        array(
                                array("value"=>"Canonify",	"display_name"=>gettext("Canonify - Canonify")),
                                array("value"=>"E",		"display_name"=>gettext("E - Exposed User")),
                                array("value"=>"G",		"display_name"=>gettext("G - Generic Domain")),
                                array("value"=>"L",		"display_name"=>gettext("L - Local User")),
                                array("value"=>"LDAPRoute",	"display_name"=>gettext("LDAPRoute - LDAP Route Domain")),
                                array("value"=>"LDAPRouteEquiv","display_name"=>gettext("LDAPRouteEquiv - LDAP Route Equivalent")),
                                array("value"=>"M",		"display_name"=>gettext("M - Masquerade Domain")),
                                array("value"=>"N",		"display_name"=>gettext("N - Masquerade Exception")),
                                array("value"=>"R",		"display_name"=>gettext("R - Relay Domain")),
                                array("value"=>"VirtHost",	"display_name"=>gettext("VirtHost - Virtual User Domain")),
                                )
                        );

		 /** Custom enum data type for sendmailMTAMapName attribute */

                $ldap_server->add_enum_data_type("sendmail_map",
                        array(
                                array("value"=>"access",	"display_name"=>gettext("access - Access Control Map")),
                                array("value"=>"authinfo",	"display_name"=>gettext("authinfo - Client Authentication Map")),
                                array("value"=>"bitdomain",	"display_name"=>gettext("bitdomain - BITNET Domain Map")),
                                array("value"=>"domain",	"display_name"=>gettext("domain - Internet Domain Map")),
                                array("value"=>"generics",	"display_name"=>gettext("generics - Generic Address Map")),
                                array("value"=>"mailer",	"display_name"=>gettext("mailer - Mailer Routing Map")),
                                array("value"=>"uucpdomain",	"display_name"=>gettext("uucpdomain - UUCPNET Domain Map")),
                                array("value"=>"virtuser",	"display_name"=>gettext("virtuser - Virtual User Map"))
                                )
                        );

		// Attributes

		$this->attribute_schema = array(
			array("name"=>"sendmailMTAAliasGrouping",	"data_type"=>"text_list",	"display_name"=>gettext("Alias Group")),
			array("name"=>"sendmailMTAAliasSearch",		"data_type"=>"text",		"display_name"=>gettext("Alias Value Recursive Search")),
			array("name"=>"sendmailMTAAliasURL",		"data_type"=>"text",		"display_name"=>gettext("Alias Value Recursive Search URL")),
			array("name"=>"sendmailMTAAliasValue",		"data_type"=>"text_list",	"display_name"=>gettext("Alias Recipient")),
			array("name"=>"sendmailMTAClassName",		"data_type"=>"sendmail_class",	"display_name"=>gettext("MTA Class Name")),
			array("name"=>"sendmailMTAClassSearch",		"data_type"=>"text",		"display_name"=>gettext("MTA Class Member Value Recursive Search")),
			array("name"=>"sendmailMTAClassURL",		"data_type"=>"text",		"display_name"=>gettext("MTA Class Member Value Recursive Search URL")),
			array("name"=>"sendmailMTAClassValue",		"data_type"=>"text_list",	"display_name"=>gettext("MTA Class Member Value")),
			array("name"=>"sendmailMTACluster",		"data_type"=>"text",		"display_name"=>gettext("MTA Cluster Name")),
			array("name"=>"sendmailMTAHost",		"data_type"=>"text",		"display_name"=>gettext("MTA Host Name")),
			array("name"=>"sendmailMTAKey",			"data_type"=>"text",		"display_name"=>gettext("Alias/Map Key")),
			array("name"=>"sendmailMTAMapName",		"data_type"=>"sendmail_map",	"display_name"=>gettext("Map Name")),
			array("name"=>"sendmailMTAMapSearch",		"data_type"=>"text",		"display_name"=>gettext("Map Value Recursive Search")),
			array("name"=>"sendmailMTAMapURL",		"data_type"=>"text",		"display_name"=>gettext("Map Value Recursive Search URL")),
			array("name"=>"sendmailMTAMapValue",		"data_type"=>"text",		"display_name"=>gettext("Map Value"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"sendmailMTA",		"icon"=>"generic24.png",		"is_folder"=>false,"display_name"=>gettext("Sendmail Object")),
			array("name"=>"sendmailMTAAlias",	"icon"=>"alias.png",			"is_folder"=>true,"rdn_attrib"=>"sendmailMTAKey","display_name"=>gettext("Sendmail Alias"),"can_contain"=>"sendmailMTAAliasObject","parent_class"=>"sendmailMTA"),
			array("name"=>"sendmailMTAAliasObject",	"icon"=>"user-alias24.png",		"is_folder"=>false,"rdn_attrib"=>"sendmailMTAKey","display_name"=>gettext("Sendmail Alias Entry"),"can_create"=>true,"parent_class"=>"sendmailMTAAlias"),
			array("name"=>"sendmailMTAClass",	"icon"=>"object.png",			"is_folder"=>false,"rdn_attrib"=>"sendmailMTAClassName","display_name"=>gettext("Sendmail Class"),"can_create"=>true,"parent_class"=>"sendmailMTA"),
			array("name"=>"sendmailMTAMap",		"icon"=>"sendmail/map.png",		"is_folder"=>true,"rdn_attrib"=>"sendmailMTAMapName","display_name"=>gettext("Sendmail Map"),"can_create"=>true,"can_contain"=>"sendmailMTAMapObject","parent_class"=>"sendmailMTA"),
			array("name"=>"sendmailMTAMapObject",	"icon"=>"sendmail/map-entry.png",	"is_folder"=>false,"rdn_attrib"=>"sendmailMTAKey","display_name"=>gettext("Sendmail Map Entry"),"can_create"=>true,"parent_class"=>"sendmailMTAMap"),
			);

		// Display layouts

		$ldap_server->add_display_layout("sendmailMTAAliasObject",array(
			array("section_name"=>gettext("Sendmail Alias"),
				"attributes"=>array(
					array("sendmailMTAKey",			gettext("Alias Name"),			"user-alias24.png"),
					array("description",			gettext("Description"),			"description.png"),
					)
				),
			array("section_name"=>gettext("Recipients"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAAliasValue")
					)
				),

			// Optional attributes for retrieving additional values via an LDAP search
			// filter expression and/or LDAP search URL.

		//	array("section_name"=>gettext("Additional Recipients via LDAP Search Filter"),"new_row"=>true,
		//		"attributes"=>array(
		//			array("sendmailMTAAliasSearch")
		//			)
		//		),
		//	array("section_name"=>gettext("Additional Recipients via LDAP URL"),"new_row"=>true,
		//		"attributes"=>array(
		//			array("sendmailMTAAliasURL")
		//			)
		//		),

			array("section_name"=>gettext("Alias Groups"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAAliasGrouping")
					)
				),
			array("section_name"=>gettext("Make The Alias Available On The Following Host or Cluster"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAHost",		gettext("Host"),			"generic24.png"),
					array("sendmailMTACluster",		gettext("Cluster"),			"generic24.png")
					)
				)
			));

		$ldap_server->add_display_layout("sendmailMTAClass",array(
			array("section_name"=>gettext("Sendmail Class"),
				"attributes"=>array(
					array("sendmailMTAClassName",		gettext("Class Name"),			"object.png"),
					array("description",			gettext("Description"),			"description.png"),
					)
				),
			array("section_name"=>gettext("Values"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAClassValue")
					)
				),

			// Optional attributes for retrieving additional values via an LDAP search
			// filter expression and/or LDAP search URL.

		//	array("section_name"=>gettext("Additional Values via LDAP Search Filter"),"new_row"=>true,
		//		"attributes"=>array(
		//			array("sendmailMTAClassSearch")
		//			)
		//		),
		//	array("section_name"=>gettext("Additional Values via LDAP URL"),"new_row"=>true,
		//		"attributes"=>array(
		//			array("sendmailMTAClassURL")
		//			)
		//		),

			array("section_name"=>gettext("Make The Class Available On The Following Host or Cluster"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAHost",		gettext("Host"),			"generic24.png"),
					array("sendmailMTACluster",		gettext("Cluster"),			"generic24.png")
					)
				)
			));

		$ldap_server->add_display_layout("sendmailMTAMap",array(
			array("section_name"=>gettext("Sendmail Map"),
				"attributes"=>array(
					array("sendmailMTAMapName",		gettext("Map Name"),			"sendmail/map.png"),
					array("description",			gettext("Description"),			"description.png"),
					)
				),
			array("section_name"=>gettext("Make The Map Available On The Following Host or Cluster"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAHost",		gettext("Host"),			"generic24.png"),
					array("sendmailMTACluster",		gettext("Cluster"),			"generic24.png")
					)
				)
			));

		$ldap_server->add_display_layout("sendmailMTAMapObject",array(
			array("section_name"=>gettext("Sendmail Map Entry"),
				"attributes"=>array(
					array("sendmailMTAKey",			gettext("Map Entry Name (Key)"),	"sendmail/map-entry.png"),
					array("sendmailMTAMapName",		gettext("Map Name"),			"sendmail/map.png"),
					array("description",			gettext("Description"),			"description.png"),
					)
				),

			array("section_name"=>gettext("Values"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAMapValue")
					)
				),

			// Optional attributes for retrieving additional values via an LDAP search
			// filter expression and/or LDAP search URL.

		//	array("section_name"=>gettext("Additional Values via LDAP Search Filter"),"new_row"=>true,
		//		"attributes"=>array(
		//			array("sendmailMTAMapSearch")
		//			)
		//		),
		//	array("section_name"=>gettext("Additional Values via LDAP URL"),"new_row"=>true,
		//		"attributes"=>array(
		//			array("sendmailMTAMapURL")
		//			)
		//		),

			array("section_name"=>gettext("Make The Map Entry Available On The Following Host or Cluster"),"new_row"=>true,
				"attributes"=>array(
					array("sendmailMTAHost",		gettext("Host"),			"generic24.png"),
					array("sendmailMTACluster",		gettext("Cluster"),			"generic24.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}

        function populate_for_create_sendmailMTAAliasObject(&$ldap_server,&$entry)
        {
		// override the schema-defined data type that the new alias's group name can be typed in

		$ldap_server->modify_attribute_class("sendmailMTAAliasGrouping","data_type","text");

                $this->add_attrib_value($ldap_server,$entry,"sendmailMTAAliasGrouping","aliases");
        }
}
?>
