<?php
/** QMail schema */

class qmail_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		/** The accountStatus attribute indicates whether a QMail account if available for use. */

		$ldap_server->add_enum_data_type("qmail_acc_status",
			array(
				array("value"=>"active",	"display_name"=>gettext("Enabled")),
				array("value"=>"nopop",		"display_name"=>gettext("Enabled, but without POP access")),
				array("value"=>"disabled",	"display_name"=>gettext("Disabled"))
				)
			);

		/** The accountStatus attribute indicates whether .qmail files sould be used */

		$ldap_server->add_enum_data_type("qmail_dot_mode",
			array(
				array("value"=>"both",		"display_name"=>gettext("LDAP Record and Home Directory")),
				array("value"=>"ldaponly",	"display_name"=>gettext("LDAP Record Only")),
				array("value"=>"ldapwithprog",	"display_name"=>gettext("LDAP Record Only, With Delivery Program")),
				array("value"=>"dotonly",	"display_name"=>gettext("Home Directory Only")),
				array("value"=>"none",		"display_name"=>gettext("None"))
				)
			);

		// Attributes

		$this->attribute_schema = array(
			array("name"=>"accountStatus",			"data_type"=>"qmail_acc_status","display_name"=>gettext("Account Status")),
			array("name"=>"bounceadmin",			"data_type"=>"text_list",	"display_name"=>gettext("Bounce Message E-Mail Address")),
			array("name"=>"confirmtext",			"data_type"=>"text_area",	"display_name"=>gettext("Confirmation E-Mail Text")),
			array("name"=>"deliveryMode",			"data_type"=>"text_list",	"display_name"=>gettext("Delivery Mode")),
			array("name"=>"deliveryProgramPath",		"data_type"=>"text",		"display_name"=>gettext("Delivery Program Path")),
			array("name"=>"dnmember",			"data_type"=>"dn_list",		"display_name"=>gettext("Group Member DN")),
			array("name"=>"dnmoderator",			"data_type"=>"dn_list",		"display_name"=>gettext("Group Moderator DN")),
			array("name"=>"dnsender",			"data_type"=>"dn_list",		"display_name"=>gettext("Allowed Sender DN")),
			array("name"=>"filtermember",			"data_type"=>"text_list",	"display_name"=>gettext("Group Member LDAP Search Filter")),
			array("name"=>"filtersender",			"data_type"=>"text_list",	"display_name"=>gettext("Allowed Sender LDAP Search Filter")),
			array("name"=>"mailAlternateAddress",		"data_type"=>"text_list",	"display_name"=>gettext("Alternate E-Mail Address")),
			array("name"=>"mailForwardingAddress",		"data_type"=>"text_list",	"display_name"=>gettext("Forwarding Address")),
			array("name"=>"mailHost",			"data_type"=>"text",		"display_name"=>gettext("Message Store Host")),
			array("name"=>"mailMessageStore",		"data_type"=>"text",		"display_name"=>gettext("Message Store Path")),
			array("name"=>"mailQuota",			"data_type"=>"text",		"display_name"=>gettext("Mail Quota")),		// obsolete
			array("name"=>"mailQuotaCount",			"data_type"=>"text",		"display_name"=>gettext("Message Count Quota")),
			array("name"=>"mailQuotaSize",			"data_type"=>"text",		"display_name"=>gettext("Message Storage Quota")),
			array("name"=>"mailReplyText",			"data_type"=>"text_area",	"display_name"=>gettext("Auto-Reply Message Text")),
			array("name"=>"mailSizeMax",			"data_type"=>"text",		"display_name"=>gettext("Maximum Accepted Message Size")),
			array("name"=>"membersonly",			"data_type"=>"yes_no",		"display_name"=>gettext("Sending Requires Group Membership")),
			array("name"=>"moderatortext",			"data_type"=>"text_area",	"display_name"=>gettext("Moderation E-Mail Text")),
			array("name"=>"qladnmanager",			"data_type"=>"dn_list",		"display_name"=>gettext("QLA Manager DN")),
			array("name"=>"qlaDomainList",			"data_type"=>"text_list",	"display_name"=>gettext("QLA Domain List")),
			array("name"=>"qlaUidPrefix",			"data_type"=>"text",		"display_name"=>gettext("QLA UID Prefix")),
			array("name"=>"qlaQmailUid",			"data_type"=>"text",		"display_name"=>gettext("QLA QMail User ID Number")),
			array("name"=>"qlaQmailGid",			"data_type"=>"text",		"display_name"=>gettext("QLA QMail Group ID Number")),
			array("name"=>"qlaMailMStorePrefix",		"data_type"=>"text",		"display_name"=>gettext("QLA Message Store Prefix")),
			array("name"=>"qlaMailQuotaSize",		"data_type"=>"text",		"display_name"=>gettext("QLA Message Storage Quota")),
			array("name"=>"qlaMailQuotaCount",		"data_type"=>"text",		"display_name"=>gettext("QLA Message Count Quota")),
			array("name"=>"qlaMailSizeMax",			"data_type"=>"text",		"display_name"=>gettext("QLA Maximum Accepted Message Size")),
			array("name"=>"qlaMailHostList",		"data_type"=>"text_list",	"display_name"=>gettext("QLA Message Store Host List")),
			array("name"=>"qmailAccountPurge",		"data_type"=>"text",		"display_name"=>gettext("Account Purge Date")),
			array("name"=>"qmailGID",			"data_type"=>"text",		"display_name"=>gettext("QMail Group ID Number")),
			array("name"=>"qmailDotMode",			"data_type"=>"qmail_dot_mode",	"display_name"=>gettext("Use of .qmail Files")),
			array("name"=>"qmailUID",			"data_type"=>"text",		"display_name"=>gettext("QMail User ID Number")),
			array("name"=>"rfc822member",			"data_type"=>"text_list",	"display_name"=>gettext("Group Member E-Mail Address")),
			array("name"=>"rfc822moderator",		"data_type"=>"text_list",	"display_name"=>gettext("Group Moderator E-Mail Address")),
			array("name"=>"rfc822sender",			"data_type"=>"text_list",	"display_name"=>gettext("Allowed Sender E-Mail Address")),
			array("name"=>"senderconfirm",			"data_type"=>"yes_no",		"display_name"=>gettext("Sending Requires Confirmation E-Mail"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"qldapAdmin",		"icon"=>"user24.png",			"class_type"=>"auxiliary","display_name"=>gettext("QMail-LDAP Subtree Admin"),"required_attribs"=>"qlaDnManager,qlaDomainList,qlaMailMStorePrefix,qlaMailHostList"),
			array("name"=>"qmailGroup",		"icon"=>"group24.png",			"class_type"=>"auxiliary","display_name"=>gettext("QMail-LDAP Group"),"required_attribs"=>"mail,mailAlternateAddress,mailMessageStore","can_create"=>true),
			array("name"=>"qmailUser",		"icon"=>"user24.png",			"class_type"=>"auxiliary","display_name"=>gettext("QMail-LDAP User"),"required_attribs"=>"mail","can_create"=>true)
			);

		// Display layouts

		$ldap_server->add_display_layout("qmailGroup",array(
			array("section_name"=>gettext("QMail Group Settings"),
				"attributes"=>array(
					array("mail",				gettext("Main E-mail"),			"mail.png"),
					array("mailAlternateAddress",		gettext("Confirmation/Moderation E-Mail"),"mail.png"),
					array("mailMessageStore",		gettext("Message Store Path"),		"folder.png"),
					)
				),
			array("section_name"=>gettext("Senders"),"new_row"=>true,
				"attributes"=>array(
					array("rfc822sender",			gettext("E-mail Addresses"),		"mail.png"),
					array("dnsender",			gettext("LDAP Records"),		"mail.png"),
					array("filtersender",			gettext("LDAP Search Expression"),	"mail.png"),
					array("membersonly",			gettext("Must Also Be Recipient"),	"generic24.png"),
					array("senderconfirm",			gettext("Must Answer Confirmation E-mail"),"generic24.png"),
					array("confirmtext",			gettext("Sender Confirmation E-mail Text"),"document.png"),
					)
				),
			array("section_name"=>gettext("Moderators"),"new_row"=>true,
				"attributes"=>array(
					array("rfc822moderator",		gettext("E-mail Addresses"),		"mail.png"),
					array("dnmoderator",			gettext("LDAP Records"),		"mail.png"),
					array("moderatortext",			gettext("Moderator Confirmation E-mail Text"),"document.png"),
					array("bounceadmin",			gettext("E-mail Addresses for Bounces"),"mail.png"),
					)
				),
			array("section_name"=>gettext("Recipients"),"new_row"=>true,
				"attributes"=>array(
					array("rfc822member",			gettext("E-mail Addresses"),		"mail.png"),
					array("dnmember",			gettext("LDAP Records"),		"mail.png"),
					array("filtermember",			gettext("LDAP Search Expression"),	"mail.png"),
					)
				)
			));

		$ldap_server->add_display_layout("qmailUser",array(
			array("section_name"=>gettext("QMail User Settings"),
				"attributes"=>array(
					array("uid",				gettext("User ID"),			"contact24.png"),
					array("qmailUID",			gettext("User ID Number"),		"id.png"),
					array("qmailGID",			gettext("Group ID Number"),		"id.png"),
					array("accountStatus",			gettext("Account Status"),		"generic24.png"),
					array("qmailDotMode",			gettext("Read User Settings From"),	"config-file.png"),
					array("homeDirectory",			gettext("Home Directory"),		"folder.png"),
					array("mail",				gettext("E-mail"),			"mail.png"),
					array("mailAlternateAddress",		gettext("Alternate E-mail"),		"mail.png"),
					// array("userPassword",		gettext("Password"),			"password.png"),
					array("qmailAccountPurge",		gettext("Don't Purge Before"),		"date.png")
					)
				),
			array("section_name"=>gettext("Mail Delivery"),"new_row"=>true,
				"attributes"=>array(
					array("deliveryMode",			gettext("Mail Delivery Mode"),		"generic24.png"),
					array("mailForwardingAddress",		gettext("Forwarding Address"),		"mail.png"),
					array("deliveryProgramPath",		gettext("Delivery Program"),		"generic24.png"),
					array("mailSizeMax",			gettext("Maximum Message Size (bytes)"),"generic24.png")
					)
				),
			array("section_name"=>gettext("Auto-Reply Message Text"),"new_row"=>true,
				"attributes"=>array(
					array("mailReplyText")
					)
				),
			array("section_name"=>gettext("Message Store"),"new_row"=>true,
				"attributes"=>array(
					array("mailHost",			gettext("Host"),			"server.png"),
					array("mailMessageStore",		gettext("Message Store Path"),		"folder.png"),
					array("mailQuotaSize",			gettext("Quota (bytes)"),		"generic24.png"),
					array("mailQuotaCount",			gettext("Quota (items)"),		"generic24.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}

        function populate_for_create_qmailGroup(&$ldap_server,&$entry)
        {
                // override the schema-defined data type that the new group's addresses can be typed in

                $ldap_server->modify_attribute_class("mail","data_type","text");
                $ldap_server->modify_attribute_class("mailAlternateAddress","data_type","text");
        }

        function populate_for_create_qmailUser(&$ldap_server,&$entry)
        {
                // override the schema-defined data type that the new user's address can be typed in

                $ldap_server->modify_attribute_class("mail","data_type","text");
        }
}
?>
