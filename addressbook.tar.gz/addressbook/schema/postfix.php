<?php
/** Postfix schema (partial)

    @see http://www.postfix.org/LDAP_README.html
*/

class postfix_schema extends ldap_schema
{
	function __construct(&$ldap_server)
	{
		// Attributes

		$this->attribute_schema = array(
			array("name"=>"mailacceptinggeneralid",		"data_type"=>"text",	"display_name"=>gettext("Incoming E-Mail Address")),
			array("name"=>"maildrop",			"data_type"=>"text",	"display_name"=>gettext("Destination Mailbox"))
			);

		// Object classes

		$this->object_schema = array(
			array("name"=>"postfixUser",		"icon"=>"mailbox-server.png",		"class_type"=>"auxiliary","display_name"=>gettext("Postfix Mail Recipient Settings"),"can_create"=>true)
			);

		// Auxiliary class display layouts

		$ldap_server->add_display_layout("postfixUser",array(
			array("section_name"=>gettext("Postfix Mail Recipient Settings"),
				"attributes"=>array(
					array("mailacceptinggeneralid",		gettext("Incoming E-Mail Address"),	"mail-transport.png"),
					array("maildrop",			gettext("Destination Mailbox"),		"mailbox-server.png")
					)
				)
			));

		parent::__construct($ldap_server);
	}
}
?>
